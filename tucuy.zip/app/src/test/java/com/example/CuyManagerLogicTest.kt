package com.example

import com.example.data.model.CamadaEntity
import com.example.data.model.CruceEntity
import com.example.data.model.CuyEntity
import com.example.logic.GeneticCalculator
import com.example.logic.NivelRiesgo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CuyManagerLogicTest {

    @Test
    fun testFullSiblingsConsanguinityProhibited() {
        val madre = CuyEntity(id = 1, codigo = "M-1", nombre = "Madre 1", sexo = "Hembra", raza = "Perú", fechaNacimiento = 1000L, poza = "P1")
        val padre = CuyEntity(id = 2, codigo = "P-1", nombre = "Padre 1", sexo = "Macho", raza = "Perú", fechaNacimiento = 1000L, poza = "P1")
        val hermano = CuyEntity(id = 3, codigo = "H-1", nombre = "Hermano", sexo = "Macho", raza = "Perú", fechaNacimiento = 2000L, madreId = 1, padreId = 2, poza = "P2")
        val hermana = CuyEntity(id = 4, codigo = "H-2", nombre = "Hermana", sexo = "Hembra", raza = "Perú", fechaNacimiento = 2000L, madreId = 1, padreId = 2, poza = "P3")

        val mapa = listOf(madre, padre, hermano, hermana).associateBy { it.id }

        val analisis = GeneticCalculator.evaluarCruce(hermano, hermana, mapa)
        assertEquals(NivelRiesgo.PROHIBIDO_HERMANOS, analisis.nivelRiesgo)
        assertEquals(25.0f, analisis.coeficienteF, 0.01f)
        assertFalse(analisis.nivelRiesgo.esApto)
    }

    @Test
    fun testParentOffspringConsanguinityProhibited() {
        val padre = CuyEntity(id = 2, codigo = "P-1", nombre = "Padre 1", sexo = "Macho", raza = "Perú", fechaNacimiento = 1000L, poza = "P1")
        val hija = CuyEntity(id = 4, codigo = "H-2", nombre = "Hija", sexo = "Hembra", raza = "Perú", fechaNacimiento = 2000L, madreId = 1, padreId = 2, poza = "P3")

        val mapa = mapOf(padre.id to padre, hija.id to hija)

        val analisis = GeneticCalculator.evaluarCruce(padre, hija, mapa)
        assertEquals(NivelRiesgo.PROHIBIDO_PARENTAL, analisis.nivelRiesgo)
        assertEquals(25.0f, analisis.coeficienteF, 0.01f)
        assertFalse(analisis.nivelRiesgo.esApto)
    }

    @Test
    fun testIndependentLinesAreCompatible() {
        val macho = CuyEntity(id = 10, codigo = "M-10", nombre = "Macho Externo", sexo = "Macho", raza = "Perú", fechaNacimiento = 1000L, poza = "P1")
        val hembra = CuyEntity(id = 20, codigo = "H-20", nombre = "Hembra Externa", sexo = "Hembra", raza = "Andina", fechaNacimiento = 1000L, poza = "P2")

        val mapa = mapOf(macho.id to macho, hembra.id to hembra)

        val analisis = GeneticCalculator.evaluarCruce(macho, hembra, mapa)
        assertEquals(NivelRiesgo.OPTIMO, analisis.nivelRiesgo)
        assertEquals(0.0f, analisis.coeficienteF, 0.01f)
        assertTrue(analisis.nivelRiesgo.esApto)
    }

    @Test
    fun testPedigreePreservationWhenDecommissioned() {
        // Un animal "Vendido" o "Consumido" preserva sus vínculos con padres e hijos
        val madre = CuyEntity(id = 1, codigo = "M-1", nombre = "Madre Histórica", sexo = "Hembra", raza = "Perú", fechaNacimiento = 1000L, poza = "P1", estado = "Consumido", motivoBaja = "Beneficio")
        val cria = CuyEntity(id = 2, codigo = "C-1", nombre = "Cría Activa", sexo = "Macho", raza = "Perú", fechaNacimiento = 2000L, madreId = 1, poza = "P2", estado = "Activo")

        // El vínculo sigue existiendo intacto
        assertEquals(1L, cria.madreId)
        assertEquals("Consumido", madre.estado)
    }
}
