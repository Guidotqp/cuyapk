package com.example.data.repository

import com.example.data.db.CuyDao
import com.example.data.model.CamadaEntity
import com.example.data.model.CruceEntity
import com.example.data.model.CuyEntity
import com.example.data.model.RegistroPesoEntity
import kotlinx.coroutines.flow.Flow

class CuyRepository(private val cuyDao: CuyDao) {

    val allCuyes: Flow<List<CuyEntity>> = cuyDao.getAllCuyes()
    val activeCuyes: Flow<List<CuyEntity>> = cuyDao.getActiveCuyes()
    val activeMales: Flow<List<CuyEntity>> = cuyDao.getActiveMales()
    val activeFemales: Flow<List<CuyEntity>> = cuyDao.getActiveFemales()
    val allWeightLogs: Flow<List<RegistroPesoEntity>> = cuyDao.getAllWeightLogs()
    val allCruces: Flow<List<CruceEntity>> = cuyDao.getAllCruces()
    val activeGestations: Flow<List<CruceEntity>> = cuyDao.getActiveGestations()
    val allCamadas: Flow<List<CamadaEntity>> = cuyDao.getAllCamadas()
    val pendingWeanings: Flow<List<CamadaEntity>> = cuyDao.getPendingWeaningCamadas()

    fun getCuyById(id: Long): Flow<CuyEntity?> = cuyDao.getCuyById(id)
    suspend fun getCuyByIdOnce(id: Long): CuyEntity? = cuyDao.getCuyByIdOnce(id)

    fun getWeightLogsForCuy(cuyId: Long): Flow<List<RegistroPesoEntity>> = cuyDao.getWeightLogsForCuy(cuyId)
    fun getOffspring(cuyId: Long): Flow<List<CuyEntity>> = cuyDao.getOffspring(cuyId)

    suspend fun insertCuy(cuy: CuyEntity): Long = cuyDao.insertCuy(cuy)
    suspend fun updateCuy(cuy: CuyEntity) = cuyDao.updateCuy(cuy)

    /**
     * Soft delete ("Dar de baja"): Cambia estado a Vendido, Consumido o Fallecido.
     * NUNCA borra el registro ni rompe los enlaces de pedigree / genealogía.
     */
    suspend fun softDeleteCuy(id: Long, nuevoEstado: String, fechaBaja: Long, motivo: String?) {
        cuyDao.softDeleteCuy(id, nuevoEstado, fechaBaja, motivo)
    }

    suspend fun reactivateCuy(id: Long) {
        cuyDao.reactivateCuy(id)
    }

    suspend fun insertWeightLog(registro: RegistroPesoEntity): Long = cuyDao.insertWeightLog(registro)
    suspend fun deleteWeightLog(id: Long) = cuyDao.deleteWeightLog(id)

    suspend fun insertCruce(cruce: CruceEntity): Long = cuyDao.insertCruce(cruce)
    suspend fun updateCruce(cruce: CruceEntity) = cuyDao.updateCruce(cruce)

    suspend fun insertCamada(camada: CamadaEntity): Long = cuyDao.insertCamada(camada)
    suspend fun updateCamada(camada: CamadaEntity) = cuyDao.updateCamada(camada)

    /**
     * Destete rápido por lote:
     * Actualiza la camada a 'Destetada', guarda poza de destete,
     * y genera automáticamente los registros de crías machos y hembras en el inventario.
     */
    suspend fun performBatchWeaning(
        camada: CamadaEntity,
        machosCount: Int,
        hembrasCount: Int,
        pozaMachos: String,
        pozaHembras: String,
        fechaDestete: Long,
        pesoPromedioDesteteGramos: Float?
    ) {
        // 1. Actualizar estado de la camada
        val updatedCamada = camada.copy(
            machos = machosCount,
            hembras = hembrasCount,
            estadoDestete = "Destetado",
            fechaDesteteReal = fechaDestete,
            pozaDestete = if (machosCount > 0 && hembrasCount > 0) "$pozaMachos / $pozaHembras" else pozaMachos.ifEmpty { pozaHembras }
        )
        cuyDao.updateCamada(updatedCamada)

        // 2. Registrar crías machos en el inventario
        val madre = cuyDao.getCuyByIdOnce(camada.madreId)
        val razaMadre = madre?.raza ?: "Perú"
        val timestamp = System.currentTimeMillis()

        for (i in 1..machosCount) {
            val codeNum = (timestamp % 10000 + i).toString().padStart(4, '0')
            val nuevoMacho = CuyEntity(
                codigo = "CRIA-M$codeNum",
                nombre = "Cría M-$i (${madre?.nombre ?: "Camada ${camada.id}"})",
                sexo = "Macho",
                raza = razaMadre,
                fechaNacimiento = camada.fechaParto,
                madreId = camada.madreId,
                padreId = camada.padreId,
                poza = pozaMachos,
                estado = "Activo",
                notas = "Destetado a los 21 días de la camada #${camada.id}",
                camadaOrigenId = camada.id
            )
            val newId = cuyDao.insertCuy(nuevoMacho)
            if (pesoPromedioDesteteGramos != null && pesoPromedioDesteteGramos > 0) {
                cuyDao.insertWeightLog(
                    RegistroPesoEntity(
                        cuyId = newId,
                        fecha = fechaDestete,
                        pesoGramos = pesoPromedioDesteteGramos,
                        notas = "Peso al destete (21 días)"
                    )
                )
            }
        }

        // 3. Registrar crías hembras en el inventario
        for (j in 1..hembrasCount) {
            val codeNum = (timestamp % 10000 + 100 + j).toString().padStart(4, '0')
            val nuevaHembra = CuyEntity(
                codigo = "CRIA-H$codeNum",
                nombre = "Cría H-$j (${madre?.nombre ?: "Camada ${camada.id}"})",
                sexo = "Hembra",
                raza = razaMadre,
                fechaNacimiento = camada.fechaParto,
                madreId = camada.madreId,
                padreId = camada.padreId,
                poza = pozaHembras,
                estado = "Activo",
                notas = "Destetada a los 21 días de la camada #${camada.id}",
                camadaOrigenId = camada.id
            )
            val newId = cuyDao.insertCuy(nuevaHembra)
            if (pesoPromedioDesteteGramos != null && pesoPromedioDesteteGramos > 0) {
                cuyDao.insertWeightLog(
                    RegistroPesoEntity(
                        cuyId = newId,
                        fecha = fechaDestete,
                        pesoGramos = pesoPromedioDesteteGramos,
                        notas = "Peso al destete (21 días)"
                    )
                )
            }
        }
    }
}
