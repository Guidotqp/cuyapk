package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entidad principal para el registro de cada cuy en el criadero.
 * Preserva siempre la genealogía incluso si el animal es dado de baja.
 */
@Entity(tableName = "cuyes")
data class CuyEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val codigo: String,                 // Código identificador único (arete/tatuaje)
    val nombre: String,                 // Nombre o apodo
    val sexo: String,                   // "Macho" o "Hembra"
    val raza: String,                   // "Perú", "Andina", "Inti", "Criollo", "California", "Línea Mejorada"
    val fechaNacimiento: Long,          // Timestamp en milisegundos
    val madreId: Long? = null,          // Referencia a CuyEntity madre (árbol genealógico)
    val padreId: Long? = null,          // Referencia a CuyEntity padre (árbol genealógico)
    val poza: String,                   // Poza / Jaula actual
    val estado: String = "Activo",       // "Activo", "Vendido", "Consumido", "Fallecido"
    val fechaBaja: Long? = null,        // Timestamp si fue dado de baja
    val motivoBaja: String? = null,     // Razón o notas de la baja
    val notas: String = "",             // Observaciones fenotípicas, características
    val colorPelaje: String = "Alazán con blanco", // Fenotipo de pelaje
    val camadaOrigenId: Long? = null    // Camada de origen si aplica
)
