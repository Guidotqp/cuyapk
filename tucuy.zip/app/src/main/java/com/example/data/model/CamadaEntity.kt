package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Registro de camada nacida.
 * Notificación de destete automática a los 21 días de edad.
 */
@Entity(tableName = "camadas")
data class CamadaEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val cruceId: Long? = null,
    val madreId: Long,
    val padreId: Long? = null,
    val fechaParto: Long,
    val fechaDesteteProgramada: Long, // fechaParto + 21 días
    val criasVivas: Int,
    val criasMuertas: Int = 0,
    val machos: Int = 0,
    val hembras: Int = 0,
    val estadoDestete: String = "Pendiente", // "Pendiente", "Destetado", "Omitido"
    val fechaDesteteReal: Long? = null,
    val pozaDestete: String? = null,
    val notas: String = ""
)
