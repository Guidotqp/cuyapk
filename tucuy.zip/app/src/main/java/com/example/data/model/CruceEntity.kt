package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Registro de monta / apareamiento para seguimiento de gestación.
 * Período de gestación promedio del cuy: 67 días.
 * Alertas de parto inician desde el día 62.
 */
@Entity(tableName = "cruces")
data class CruceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val machoId: Long,
    val hembraId: Long,
    val fechaMonta: Long,
    val fechaPartoEstimada: Long,     // fechaMonta + 67 días
    val fechaPartoReal: Long? = null,
    val estado: String = "En gestación", // "En gestación", "Parida", "No preñada"
    val poza: String,
    val notas: String = ""
)
