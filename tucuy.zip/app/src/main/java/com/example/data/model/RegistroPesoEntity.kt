package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Registro de pesaje periódico para análisis de ganancia diaria de peso
 * y curvas de crecimiento en comparación al promedio de la granja.
 */
@Entity(
    tableName = "registros_peso",
    foreignKeys = [
        ForeignKey(
            entity = CuyEntity::class,
            parentColumns = ["id"],
            childColumns = ["cuyId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["cuyId"]), Index(value = ["fecha"])]
)
data class RegistroPesoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val cuyId: Long,
    val fecha: Long,             // Timestamp de la fecha del pesaje
    val pesoGramos: Float,       // Peso en gramos
    val notas: String = ""       // Notas (ej. "Post-destete", "Antes de monta")
)
