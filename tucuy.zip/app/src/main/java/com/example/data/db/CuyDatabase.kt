package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.CamadaEntity
import com.example.data.model.CruceEntity
import com.example.data.model.CuyEntity
import com.example.data.model.RegistroPesoEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        CuyEntity::class,
        RegistroPesoEntity::class,
        CruceEntity::class,
        CamadaEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CuyDatabase : RoomDatabase() {
    abstract fun cuyDao(): CuyDao

    companion object {
        @Volatile
        private var INSTANCE: CuyDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): CuyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CuyDatabase::class.java,
                    "cuy_manager_database"
                )
                .addCallback(CuyDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class CuyDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.cuyDao())
                }
            }
        }

        private suspend fun populateInitialData(dao: CuyDao) {
            val now = System.currentTimeMillis()
            val dayMillis = 86_400_000L

            // 1. Abuelos / Fundadores
            val abueloPat = CuyEntity(
                id = 1,
                codigo = "CUY-001",
                nombre = "Apu Líder",
                sexo = "Macho",
                raza = "Perú",
                fechaNacimiento = now - (360 * dayMillis),
                madreId = null,
                padreId = null,
                poza = "Poza Machos 1",
                estado = "Activo",
                notas = "Macho reproductor fundador de alta ganancia de peso"
            )
            val abuelaPat = CuyEntity(
                id = 2,
                codigo = "CUY-002",
                nombre = "Killa Reina",
                sexo = "Hembra",
                raza = "Perú",
                fechaNacimiento = now - (350 * dayMillis),
                madreId = null,
                padreId = null,
                poza = "Poza Madres 1",
                estado = "Activo",
                notas = "Excelente prolificidad (camadas de 4 a 5 crías)"
            )
            val abueloMat = CuyEntity(
                id = 3,
                codigo = "CUY-003",
                nombre = "Huáscar",
                sexo = "Macho",
                raza = "Andina",
                fechaNacimiento = now - (380 * dayMillis),
                madreId = null,
                padreId = null,
                poza = "Poza Machos 2",
                estado = "Vendido",
                fechaBaja = now - (60 * dayMillis),
                motivoBaja = "Vendido como reproductor de pie de cría a granja asociada",
                notas = "Línea Andina prolífica"
            )
            val abuelaMat = CuyEntity(
                id = 4,
                codigo = "CUY-004",
                nombre = "Sumaq",
                sexo = "Hembra",
                raza = "Andina",
                fechaNacimiento = now - (370 * dayMillis),
                madreId = null,
                padreId = null,
                poza = "Poza Madres 2",
                estado = "Activo",
                notas = "Madre dócil y productiva"
            )

            // 2. Padres (Segunda generación)
            val padrePrincipal = CuyEntity(
                id = 5,
                codigo = "CUY-005",
                nombre = "Inti Campeón",
                sexo = "Macho",
                raza = "Perú",
                fechaNacimiento = now - (220 * dayMillis),
                madreId = 2,
                padreId = 1,
                poza = "Poza Reproductores A",
                estado = "Activo",
                notas = "Hijo de Apu Líder y Killa. Gran conformación de carne."
            )
            val madrePrincipal = CuyEntity(
                id = 6,
                codigo = "CUY-006",
                nombre = "Chispita",
                sexo = "Hembra",
                raza = "Andina-Perú",
                fechaNacimiento = now - (200 * dayMillis),
                madreId = 4,
                padreId = 3,
                poza = "Maternidad 1",
                estado = "Activo",
                notas = "Madre prolífica con camada actual en destete"
            )
            val madreDos = CuyEntity(
                id = 7,
                codigo = "CUY-007",
                nombre = "Blanquita",
                sexo = "Hembra",
                raza = "Inti",
                fechaNacimiento = now - (210 * dayMillis),
                madreId = null,
                padreId = null,
                poza = "Maternidad 2",
                estado = "Activo",
                notas = "En gestación avanzada (día 63)"
            )
            val tíaMaterna = CuyEntity(
                id = 8,
                codigo = "CUY-008",
                nombre = "Canelita",
                sexo = "Hembra",
                raza = "Andina",
                fechaNacimiento = now - (200 * dayMillis),
                madreId = 4,
                padreId = 3,
                poza = "Poza Hembras 3",
                estado = "Activo",
                notas = "Hermana completa de Chispita"
            )

            // 3. Hijos (Tercera generación - Hermanos de camada)
            val hermanoUno = CuyEntity(
                id = 9,
                codigo = "CUY-009",
                nombre = "Rayito",
                sexo = "Macho",
                raza = "Perú",
                fechaNacimiento = now - (60 * dayMillis),
                madreId = 6,
                padreId = 5,
                poza = "Poza Recría M-1",
                estado = "Activo",
                notas = "Cría de Inti Campeón y Chispita"
            )
            val hermanaDos = CuyEntity(
                id = 10,
                codigo = "CUY-010",
                nombre = "Estrellita",
                sexo = "Hembra",
                raza = "Perú",
                fechaNacimiento = now - (60 * dayMillis),
                madreId = 6,
                padreId = 5,
                poza = "Poza Recría H-1",
                estado = "Activo",
                notas = "Hermana de camada de Rayito"
            )
            val animalConsumido = CuyEntity(
                id = 11,
                codigo = "CUY-011",
                nombre = "Gordito",
                sexo = "Macho",
                raza = "Perú",
                fechaNacimiento = now - (120 * dayMillis),
                madreId = 6,
                padreId = 5,
                poza = "Registro Histórico",
                estado = "Consumido",
                fechaBaja = now - (10 * dayMillis),
                motivoBaja = "Beneficio para consumo familiar (peso óptimo 1,180g)",
                notas = "Excelente conversión alimenticia"
            )

            val initialCuyes = listOf(
                abueloPat, abuelaPat, abueloMat, abuelaMat,
                padrePrincipal, madrePrincipal, madreDos, tíaMaterna,
                hermanoUno, hermanaDos, animalConsumido
            )
            dao.insertCuyes(initialCuyes)

            // 4. Registros de Pesaje para curvas de crecimiento y promedios
            val pesos = mutableListOf<RegistroPesoEntity>()
            // Pesajes de Rayito (id 9, nacido hace 60 días)
            pesos.add(RegistroPesoEntity(cuyId = 9, fecha = now - (60 * dayMillis), pesoGramos = 115f, notas = "Peso al nacimiento"))
            pesos.add(RegistroPesoEntity(cuyId = 9, fecha = now - (39 * dayMillis), pesoGramos = 320f, notas = "Peso al destete (21 días)"))
            pesos.add(RegistroPesoEntity(cuyId = 9, fecha = now - (18 * dayMillis), pesoGramos = 540f, notas = "Control recría"))
            pesos.add(RegistroPesoEntity(cuyId = 9, fecha = now - (2 * dayMillis), pesoGramos = 720f, notas = "Control 60 días - sobresaliente"))

            // Pesajes de Estrellita (id 10)
            pesos.add(RegistroPesoEntity(cuyId = 10, fecha = now - (60 * dayMillis), pesoGramos = 105f, notas = "Peso al nacimiento"))
            pesos.add(RegistroPesoEntity(cuyId = 10, fecha = now - (39 * dayMillis), pesoGramos = 295f, notas = "Peso al destete (21 días)"))
            pesos.add(RegistroPesoEntity(cuyId = 10, fecha = now - (18 * dayMillis), pesoGramos = 490f, notas = "Control recría"))
            pesos.add(RegistroPesoEntity(cuyId = 10, fecha = now - (2 * dayMillis), pesoGramos = 660f, notas = "Control 60 días"))

            // Pesajes del reproductor Inti Campeón (id 5)
            pesos.add(RegistroPesoEntity(cuyId = 5, fecha = now - (200 * dayMillis), pesoGramos = 340f, notas = "Destete"))
            pesos.add(RegistroPesoEntity(cuyId = 5, fecha = now - (140 * dayMillis), pesoGramos = 750f, notas = "Selección recría"))
            pesos.add(RegistroPesoEntity(cuyId = 5, fecha = now - (60 * dayMillis), pesoGramos = 1150f, notas = "Inicio como reproductor"))
            pesos.add(RegistroPesoEntity(cuyId = 5, fecha = now - (5 * dayMillis), pesoGramos = 1290f, notas = "Peso adulto óptimo"))

            // Pesajes de Chispita (id 6)
            pesos.add(RegistroPesoEntity(cuyId = 6, fecha = now - (180 * dayMillis), pesoGramos = 310f, notas = "Destete"))
            pesos.add(RegistroPesoEntity(cuyId = 6, fecha = now - (100 * dayMillis), pesoGramos = 820f, notas = "Control"))
            pesos.add(RegistroPesoEntity(cuyId = 6, fecha = now - (25 * dayMillis), pesoGramos = 1080f, notas = "Post-parto"))

            dao.insertWeightLogs(pesos)

            // 5. Camada lista para destete (Exactamente a los 21 días de nacida hoy!)
            // Parto ocurrió hace 21 días
            val fechaPartoCamada = now - (21 * dayMillis)
            val camadaDestete = CamadaEntity(
                id = 1,
                cruceId = null,
                madreId = 6, // Chispita
                padreId = 5, // Inti Campeón
                fechaParto = fechaPartoCamada,
                fechaDesteteProgramada = fechaPartoCamada + (21 * dayMillis), // Hoy!
                criasVivas = 4,
                criasMuertas = 0,
                machos = 2,
                hembras = 2,
                estadoDestete = "Pendiente",
                pozaDestete = null,
                notas = "Camada vigorosa nacida en Maternidad 1"
            )
            dao.insertCamada(camadaDestete)

            // 6. Cruce con Gestación avanzada (Día 63 de 67 días: Parto próximo en 4 días!)
            val fechaMontaBlanquita = now - (63 * dayMillis)
            val cruceProximoParto = CruceEntity(
                id = 1,
                machoId = 5, // Inti Campeón
                hembraId = 7, // Blanquita
                fechaMonta = fechaMontaBlanquita,
                fechaPartoEstimada = fechaMontaBlanquita + (67 * dayMillis), // en 4 días
                estado = "En gestación",
                poza = "Maternidad 2",
                notas = "Hembra primípara en excelentes condiciones sanitarias"
            )
            dao.insertCruce(cruceProximoParto)
        }
    }
}
