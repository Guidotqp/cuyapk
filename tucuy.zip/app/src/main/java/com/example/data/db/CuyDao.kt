package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CamadaEntity
import com.example.data.model.CruceEntity
import com.example.data.model.CuyEntity
import com.example.data.model.RegistroPesoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CuyDao {
    // --- CUYES ---
    @Query("SELECT * FROM cuyes ORDER BY fechaNacimiento DESC")
    fun getAllCuyes(): Flow<List<CuyEntity>>

    @Query("SELECT * FROM cuyes WHERE id = :id")
    fun getCuyById(id: Long): Flow<CuyEntity?>

    @Query("SELECT * FROM cuyes WHERE id = :id")
    suspend fun getCuyByIdOnce(id: Long): CuyEntity?

    @Query("SELECT * FROM cuyes WHERE estado = 'Activo' ORDER BY nombre ASC")
    fun getActiveCuyes(): Flow<List<CuyEntity>>

    @Query("SELECT * FROM cuyes WHERE sexo = 'Macho' AND estado = 'Activo' ORDER BY nombre ASC")
    fun getActiveMales(): Flow<List<CuyEntity>>

    @Query("SELECT * FROM cuyes WHERE sexo = 'Hembra' AND estado = 'Activo' ORDER BY nombre ASC")
    fun getActiveFemales(): Flow<List<CuyEntity>>

    @Query("SELECT * FROM cuyes WHERE madreId = :cuyId OR padreId = :cuyId ORDER BY fechaNacimiento DESC")
    fun getOffspring(cuyId: Long): Flow<List<CuyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCuy(cuy: CuyEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCuyes(cuyes: List<CuyEntity>)

    @Update
    suspend fun updateCuy(cuy: CuyEntity)

    @Query("UPDATE cuyes SET estado = :nuevoEstado, fechaBaja = :fechaBaja, motivoBaja = :motivo WHERE id = :id")
    suspend fun softDeleteCuy(id: Long, nuevoEstado: String, fechaBaja: Long, motivo: String?)

    @Query("UPDATE cuyes SET estado = 'Activo', fechaBaja = NULL, motivoBaja = NULL WHERE id = :id")
    suspend fun reactivateCuy(id: Long)

    // --- REGISTROS DE PESO ---
    @Query("SELECT * FROM registros_peso WHERE cuyId = :cuyId ORDER BY fecha ASC")
    fun getWeightLogsForCuy(cuyId: Long): Flow<List<RegistroPesoEntity>>

    @Query("SELECT * FROM registros_peso ORDER BY fecha ASC")
    fun getAllWeightLogs(): Flow<List<RegistroPesoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightLog(registro: RegistroPesoEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightLogs(registros: List<RegistroPesoEntity>)

    @Query("DELETE FROM registros_peso WHERE id = :id")
    suspend fun deleteWeightLog(id: Long)

    // --- CRUCES & GESTACIÓN ---
    @Query("SELECT * FROM cruces ORDER BY fechaMonta DESC")
    fun getAllCruces(): Flow<List<CruceEntity>>

    @Query("SELECT * FROM cruces WHERE estado = 'En gestación' ORDER BY fechaPartoEstimada ASC")
    fun getActiveGestations(): Flow<List<CruceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCruce(cruce: CruceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCruces(cruces: List<CruceEntity>)

    @Update
    suspend fun updateCruce(cruce: CruceEntity)

    // --- CAMADAS & DESTETE ---
    @Query("SELECT * FROM camadas ORDER BY fechaParto DESC")
    fun getAllCamadas(): Flow<List<CamadaEntity>>

    @Query("SELECT * FROM camadas WHERE estadoDestete = 'Pendiente' ORDER BY fechaDesteteProgramada ASC")
    fun getPendingWeaningCamadas(): Flow<List<CamadaEntity>>

    @Query("SELECT * FROM camadas WHERE id = :id")
    suspend fun getCamadaById(id: Long): CamadaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCamada(camada: CamadaEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCamadas(camadas: List<CamadaEntity>)

    @Update
    suspend fun updateCamada(camada: CamadaEntity)
}
