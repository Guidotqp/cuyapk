package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AnimalDetailScreen
import com.example.ui.screens.BreedingManagementScreen
import com.example.ui.screens.CompatibleCrossesScreen
import com.example.ui.screens.ForbiddenCrossesScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.RegisterCuyScreen
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FarmGreen
import com.example.ui.theme.FarmGreenContainer
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.WarmAmber
import com.example.ui.viewmodel.CuyViewModel

enum class CuyNavScreen(val titulo: String) {
    MIS_CUYS("Mis Cuys"),
    REGISTRAR("Registrar"),
    GESTION("Gestión"),
    CRUCES_APTOS("Cruces Aptos"),
    PROHIBIDOS("Prohibidos")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CuyManagerApp()
            }
        }
    }
}

@Composable
fun CuyManagerApp(
    viewModel: CuyViewModel = viewModel()
) {
    var currentTab by remember { mutableStateOf(CuyNavScreen.MIS_CUYS) }
    var selectedCuyId by remember { mutableStateOf<Long?>(null) }
    var isRegisteringFromFab by remember { mutableStateOf(false) }

    val weaningAlerts by viewModel.weaningAlerts.collectAsState()
    val birthAlerts by viewModel.birthAlerts.collectAsState()
    val totalAlertas = weaningAlerts.size + birthAlerts.size
    val crucesProhibidos by viewModel.crucesProhibidos.collectAsState()

    // Manejo de volver atrás con botón físico/gesto de Android
    if (selectedCuyId != null) {
        BackHandler {
            selectedCuyId = null
        }
    } else if (isRegisteringFromFab) {
        BackHandler {
            isRegisteringFromFab = false
        }
    } else if (currentTab != CuyNavScreen.MIS_CUYS) {
        BackHandler {
            currentTab = CuyNavScreen.MIS_CUYS
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Se muestra la barra de navegación siempre que no estemos en detalle profundo
            if (selectedCuyId == null && !isRegisteringFromFab) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("main_bottom_nav")
                ) {
                    // 1. Mis Cuys
                    NavigationBarItem(
                        selected = currentTab == CuyNavScreen.MIS_CUYS,
                        onClick = { currentTab = CuyNavScreen.MIS_CUYS },
                        icon = { Icon(Icons.Default.Pets, contentDescription = "Mis Cuys") },
                        label = { Text("Mis Cuys", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FarmGreenDark,
                            selectedTextColor = FarmGreenDark,
                            indicatorColor = FarmGreenContainer
                        ),
                        modifier = Modifier.testTag("nav_mis_cuys")
                    )

                    // 2. Registrar
                    NavigationBarItem(
                        selected = currentTab == CuyNavScreen.REGISTRAR,
                        onClick = { currentTab = CuyNavScreen.REGISTRAR },
                        icon = { Icon(Icons.Default.AddCircleOutline, contentDescription = "Registrar") },
                        label = { Text("Registrar", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FarmGreenDark,
                            selectedTextColor = FarmGreenDark,
                            indicatorColor = FarmGreenContainer
                        ),
                        modifier = Modifier.testTag("nav_registrar")
                    )

                    // 3. Gestión (Con badge si hay alertas de destete o parto)
                    NavigationBarItem(
                        selected = currentTab == CuyNavScreen.GESTION,
                        onClick = { currentTab = CuyNavScreen.GESTION },
                        icon = {
                            if (totalAlertas > 0) {
                                BadgedBox(badge = {
                                    Badge(containerColor = WarmAmber) {
                                        Text("$totalAlertas")
                                    }
                                }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "Gestión")
                                }
                            } else {
                                Icon(Icons.Default.CalendarMonth, contentDescription = "Gestión")
                            }
                        },
                        label = { Text("Gestión", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FarmGreenDark,
                            selectedTextColor = FarmGreenDark,
                            indicatorColor = FarmGreenContainer
                        ),
                        modifier = Modifier.testTag("nav_gestion")
                    )

                    // 4. Cruces Aptos
                    NavigationBarItem(
                        selected = currentTab == CuyNavScreen.CRUCES_APTOS,
                        onClick = { currentTab = CuyNavScreen.CRUCES_APTOS },
                        icon = { Icon(Icons.Default.Verified, contentDescription = "Cruces Aptos") },
                        label = { Text("Cruces Aptos", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FarmGreenDark,
                            selectedTextColor = FarmGreenDark,
                            indicatorColor = FarmGreenContainer
                        ),
                        modifier = Modifier.testTag("nav_cruces_aptos")
                    )

                    // 5. Prohibidos
                    NavigationBarItem(
                        selected = currentTab == CuyNavScreen.PROHIBIDOS,
                        onClick = { currentTab = CuyNavScreen.PROHIBIDOS },
                        icon = {
                            if (crucesProhibidos.isNotEmpty()) {
                                BadgedBox(badge = {
                                    Badge(containerColor = DangerRed) {
                                        Text("${crucesProhibidos.size}")
                                    }
                                }) {
                                    Icon(Icons.Default.Block, contentDescription = "Prohibidos")
                                }
                            } else {
                                Icon(Icons.Default.Block, contentDescription = "Prohibidos")
                            }
                        },
                        label = { Text("Prohibidos", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DangerRed,
                            selectedTextColor = DangerRed,
                            indicatorColor = Color(0xFFFEE2E2)
                        ),
                        modifier = Modifier.testTag("nav_prohibidos")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                selectedCuyId != null -> {
                    AnimalDetailScreen(
                        cuyId = selectedCuyId!!,
                        viewModel = viewModel,
                        onNavigateBack = { selectedCuyId = null },
                        onSelectOtherCuy = { otherId -> selectedCuyId = otherId }
                    )
                }
                isRegisteringFromFab -> {
                    RegisterCuyScreen(
                        viewModel = viewModel,
                        onNavigateBack = { isRegisteringFromFab = false }
                    )
                }
                currentTab == CuyNavScreen.MIS_CUYS -> {
                    InventoryScreen(
                        viewModel = viewModel,
                        onSelectCuy = { cuyId -> selectedCuyId = cuyId },
                        onNavigateRegister = { isRegisteringFromFab = true }
                    )
                }
                currentTab == CuyNavScreen.REGISTRAR -> {
                    RegisterCuyScreen(
                        viewModel = viewModel,
                        onNavigateBack = { currentTab = CuyNavScreen.MIS_CUYS }
                    )
                }
                currentTab == CuyNavScreen.GESTION -> {
                    BreedingManagementScreen(
                        viewModel = viewModel,
                        onSelectCuy = { cuyId -> selectedCuyId = cuyId }
                    )
                }
                currentTab == CuyNavScreen.CRUCES_APTOS -> {
                    CompatibleCrossesScreen(
                        viewModel = viewModel,
                        onSelectCuy = { cuyId -> selectedCuyId = cuyId }
                    )
                }
                currentTab == CuyNavScreen.PROHIBIDOS -> {
                    ForbiddenCrossesScreen(
                        viewModel = viewModel,
                        onSelectCuy = { cuyId -> selectedCuyId = cuyId }
                    )
                }
            }
        }
    }
}

