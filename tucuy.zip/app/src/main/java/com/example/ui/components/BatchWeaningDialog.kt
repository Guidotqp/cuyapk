package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.CamadaEntity
import com.example.ui.theme.FarmGreen

@Composable
fun BatchWeaningDialog(
    camada: CamadaEntity,
    madreNombre: String,
    onDismiss: () -> Unit,
    onConfirm: (machos: Int, hembras: Int, pozaMachos: String, pozaHembras: String, pesoPromedio: Float?) -> Unit
) {
    var machosText by remember { mutableStateOf(camada.machos.takeIf { it > 0 }?.toString() ?: (camada.criasVivas / 2).toString()) }
    var hembrasText by remember { mutableStateOf(camada.hembras.takeIf { it > 0 }?.toString() ?: (camada.criasVivas - (camada.criasVivas / 2)).toString()) }
    var pozaMachos by remember { mutableStateOf("Poza Recría M-1") }
    var pozaHembras by remember { mutableStateOf("Poza Recría H-1") }
    var pesoPromedioText by remember { mutableStateOf("320") } // Peso promedio típico a los 21 días (300-350g)
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Pets,
                    contentDescription = null,
                    tint = FarmGreen
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Destete Rápido por Lote (21 Días)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Camada de $madreNombre (${camada.criasVivas} crías vivas)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Separa la camada por sexo a los 21 días para evitar montas precoces no deseadas y optimizar la ganancia de peso.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                // Cantidades de machos y hembras
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = machosText,
                        onValueChange = { machosText = it; errorMsg = null },
                        label = { Text("Nº Machos") },
                        leadingIcon = { Icon(Icons.Default.Male, contentDescription = null, tint = Color(0xFF2563EB)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("weaning_males_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = hembrasText,
                        onValueChange = { hembrasText = it; errorMsg = null },
                        label = { Text("Nº Hembras") },
                        leadingIcon = { Icon(Icons.Default.Female, contentDescription = null, tint = Color(0xFFDB2777)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("weaning_females_input"),
                        singleLine = true
                    )
                }

                // Reasignación de Pozas / Jaulas de Destete y Engorde
                OutlinedTextField(
                    value = pozaMachos,
                    onValueChange = { pozaMachos = it },
                    label = { Text("Poza de Recría/Destete Machos") },
                    leadingIcon = { Icon(Icons.Default.MeetingRoom, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("weaning_pen_males_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = pozaHembras,
                    onValueChange = { pozaHembras = it },
                    label = { Text("Poza de Recría/Destete Hembras") },
                    leadingIcon = { Icon(Icons.Default.MeetingRoom, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("weaning_pen_females_input"),
                    singleLine = true
                )

                // Peso promedio al destete
                OutlinedTextField(
                    value = pesoPromedioText,
                    onValueChange = { pesoPromedioText = it },
                    label = { Text("Peso promedio de destete (gramos)") },
                    supportingText = { Text("Estándar óptimo INIA: 280g - 360g a los 21 días") },
                    leadingIcon = { Icon(Icons.Default.Balance, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("weaning_weight_input"),
                    singleLine = true
                )

                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val m = machosText.toIntOrNull() ?: 0
                    val h = hembrasText.toIntOrNull() ?: 0
                    if (m < 0 || h < 0 || (m + h) == 0) {
                        errorMsg = "Debe haber al menos 1 cría macho o hembra para destetar."
                        return@Button
                    }
                    val peso = pesoPromedioText.toFloatOrNull()
                    onConfirm(m, h, pozaMachos.trim(), pozaHembras.trim(), peso)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreen),
                modifier = Modifier.testTag("confirm_weaning_button")
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Confirmar Destete")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_weaning_button")
            ) {
                Text("Cancelar")
            }
        }
    )
}
