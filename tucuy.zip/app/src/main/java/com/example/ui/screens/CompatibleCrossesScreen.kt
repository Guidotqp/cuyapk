package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CuyEntity
import com.example.logic.AnalisisCruce
import com.example.logic.GeneticCalculator
import com.example.ui.theme.FarmGreen
import com.example.ui.theme.FarmGreenContainer
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.WarmAmber
import com.example.ui.viewmodel.CuyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompatibleCrossesScreen(
    viewModel: CuyViewModel,
    onSelectCuy: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val crucesAptos by viewModel.crucesAptos.collectAsState()
    val activeMales by viewModel.activeMales.collectAsState()
    val activeFemales by viewModel.activeFemales.collectAsState()
    val allCuyes by viewModel.allCuyes.collectAsState()

    // Simulador de Cruce Personalizado
    var simMachoId by remember { mutableStateOf<Long?>(null) }
    var simHembraId by remember { mutableStateOf<Long?>(null) }
    var expandedM by remember { mutableStateOf(false) }
    var expandedH by remember { mutableStateOf(false) }

    val cuyMap = remember(allCuyes) { allCuyes.associateBy { it.id } }

    val analisisPersonalizado: AnalisisCruce? = remember(simMachoId, simHembraId, allCuyes) {
        val m = simMachoId?.let { cuyMap[it] }
        val h = simHembraId?.let { cuyMap[it] }
        if (m != null && h != null) {
            GeneticCalculator.evaluarCruce(m, h, cuyMap)
        } else null
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Título y Banner explicativo
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = FarmGreen,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Cruces Aptos y Compatibles",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Selección genética para evitar consanguinidad y potenciar el vigor híbrido en el criadero.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 2. Evaluador Rápido de Cualquier Pareja
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Calculate, contentDescription = null, tint = FarmGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Calculadora de Compatibilidad Genética",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Macho
                        ExposedDropdownMenuBox(
                            expanded = expandedM,
                            onExpandedChange = { expandedM = !expandedM },
                            modifier = Modifier.weight(1f)
                        ) {
                            val machoObj = simMachoId?.let { cuyMap[it] }
                            OutlinedTextField(
                                value = machoObj?.nombre ?: "Elegir Macho...",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Macho") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedM) },
                                modifier = Modifier.menuAnchor().fillMaxWidth().testTag("select_sim_male")
                            )
                            ExposedDropdownMenu(expanded = expandedM, onDismissRequest = { expandedM = false }) {
                                activeMales.forEach { m ->
                                    DropdownMenuItem(
                                        text = { Text("${m.nombre} (${m.codigo})") },
                                        onClick = { simMachoId = m.id; expandedM = false }
                                    )
                                }
                            }
                        }

                        // Hembra
                        ExposedDropdownMenuBox(
                            expanded = expandedH,
                            onExpandedChange = { expandedH = !expandedH },
                            modifier = Modifier.weight(1f)
                        ) {
                            val hembraObj = simHembraId?.let { cuyMap[it] }
                            OutlinedTextField(
                                value = hembraObj?.nombre ?: "Elegir Hembra...",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Hembra") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedH) },
                                modifier = Modifier.menuAnchor().fillMaxWidth().testTag("select_sim_female")
                            )
                            ExposedDropdownMenu(expanded = expandedH, onDismissRequest = { expandedH = false }) {
                                activeFemales.forEach { h ->
                                    DropdownMenuItem(
                                        text = { Text("${h.nombre} (${h.codigo})") },
                                        onClick = { simHembraId = h.id; expandedH = false }
                                    )
                                }
                            }
                        }
                    }

                    // Resultado de la simulación
                    if (analisisPersonalizado != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        val esApto = analisisPersonalizado.nivelRiesgo.esApto
                        val bgResult = if (esApto) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                        val textResult = if (esApto) FarmGreenDark else Color(0xFF991B1B)

                        Surface(color = bgResult, shape = RoundedCornerShape(10.dp)) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = analisisPersonalizado.nivelRiesgo.titulo,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = textResult
                                    )
                                    Text(
                                        text = "F = ${"%.1f".format(analisisPersonalizado.coeficienteF)}%",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = textResult
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Parentesco: ${analisisPersonalizado.parentescoDetectado}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    color = textResult
                                )
                                Text(
                                    text = analisisPersonalizado.recomendaciones,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = textResult.copy(alpha = 0.9f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Encabezado de la Lista de Recomendados
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Parejas Recomendadas en el Criadero (${crucesAptos.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Consanguinidad 0%",
                    style = MaterialTheme.typography.labelSmall,
                    color = FarmGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (crucesAptos.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No hay parejas compatibles sin parentesco entre los reproductores activos registrados. Se recomienda introducir un nuevo macho reproductor externo para refrescar sangre.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(crucesAptos) { cruce ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Favorite, contentDescription = null, tint = FarmGreen, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${cruce.macho.nombre}  ×  ${cruce.hembra.nombre}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                color = Color(0xFFDCFCE7),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "0% Consanguíneo",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = FarmGreenDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Macho: ${cruce.macho.codigo} (Raza ${cruce.macho.raza}, ${cruce.macho.poza})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Hembra: ${cruce.hembra.codigo} (Raza ${cruce.hembra.raza}, ${cruce.hembra.poza})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = cruce.recomendaciones,
                            style = MaterialTheme.typography.bodySmall,
                            color = FarmGreenDark
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    viewModel.registerCruce(
                                        machoId = cruce.macho.id,
                                        hembraId = cruce.hembra.id,
                                        fechaMonta = System.currentTimeMillis(),
                                        poza = cruce.hembra.poza,
                                        notas = "Cruce genéticamente óptimo (0% consanguinidad)"
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = FarmGreen)
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Aprobar y Registrar Monta")
                            }
                        }
                    }
                }
            }
        }
    }
}
