package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CuyEntity
import com.example.data.model.RegistroPesoEntity
import com.example.logic.GeneticCalculator
import com.example.ui.components.DecommissionDialog
import com.example.ui.components.GrowthChart
import com.example.ui.components.PedigreeTree
import com.example.ui.components.StatusBadge
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FarmGreen
import com.example.ui.theme.FarmGreenContainer
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.StatusActive
import com.example.ui.theme.WarmAmber
import com.example.ui.viewmodel.CuyViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimalDetailScreen(
    cuyId: Long,
    viewModel: CuyViewModel,
    onNavigateBack: () -> Unit,
    onSelectOtherCuy: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val allCuyes by viewModel.allCuyes.collectAsState()
    val allWeightLogs by viewModel.allWeightLogs.collectAsState()

    val cuy = allCuyes.find { it.id == cuyId }
    val weights = allWeightLogs.filter { it.cuyId == cuyId }.sortedBy { it.fecha }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showDecommissionDialog by remember { mutableStateOf(false) }
    var showAddWeightDialog by remember { mutableStateOf(false) }

    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val dayMillis = 86_400_000L
    val now = System.currentTimeMillis()

    if (cuy == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Detalle del Cuy") },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                        }
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text("Ejemplar no encontrado en el criadero.")
            }
        }
        return
    }

    val edadDias = ((now - cuy.fechaNacimiento) / dayMillis).toInt().coerceAtLeast(0)
    val metricas = viewModel.calcularMetricasCrecimiento(cuy, weights, allWeightLogs, allCuyes)

    // Modal de Dar de Baja (Soft delete con preservación de pedigree)
    if (showDecommissionDialog) {
        DecommissionDialog(
            cuy = cuy,
            onDismiss = { showDecommissionDialog = false },
            onConfirm = { nuevoEstado, motivo ->
                viewModel.softDeleteCuy(
                    id = cuy.id,
                    nuevoEstado = nuevoEstado,
                    fechaBaja = now,
                    motivo = motivo
                )
                showDecommissionDialog = false
            }
        )
    }

    // Modal de Registrar Pesaje
    if (showAddWeightDialog) {
        AddWeightDialog(
            cuy = cuy,
            onDismiss = { showAddWeightDialog = false },
            onConfirm = { gramos, notas ->
                viewModel.addWeightLog(cuy.id, now, gramos, notas)
                showAddWeightDialog = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(cuy.nombre, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("${cuy.codigo} • ${cuy.raza}", style = MaterialTheme.typography.labelSmall)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    if (cuy.estado == "Activo") {
                        Button(
                            onClick = { showDecommissionDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = DangerRed.copy(alpha = 0.9f)),
                            modifier = Modifier.padding(end = 8.dp).testTag("action_decommission_cuy")
                        ) {
                            Text("Dar de baja", style = MaterialTheme.typography.labelMedium)
                        }
                    } else {
                        Button(
                            onClick = { viewModel.reactivateCuy(cuy.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreen),
                            modifier = Modifier.padding(end = 8.dp).testTag("action_reactivate_cuy")
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reactivar", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Tarjeta Resumen Principal del Cuy
            item {
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val esMacho = cuy.sexo == "Macho"
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(
                                            if (esMacho) Color(0xFFEFF6FF) else Color(0xFFFDF2F8),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (esMacho) Icons.Default.Male else Icons.Default.Female,
                                        contentDescription = cuy.sexo,
                                        tint = if (esMacho) Color(0xFF2563EB) else Color(0xFFDB2777),
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = cuy.nombre,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Arete: ${cuy.codigo} • ${cuy.sexo}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            StatusBadge(estado = cuy.estado)
                        }

                        // Aviso de baja si está inactivo
                        if (cuy.estado != "Activo") {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = Color(0xFFF1F5F9),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "Animal en registro histórico (${cuy.estado})",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF1E293B)
                                        )
                                        val fechaBajaStr = cuy.fechaBaja?.let { dateFormat.format(Date(it)) } ?: "Fecha no indicada"
                                        Text(
                                            text = "Baja: $fechaBajaStr. Motivo: ${cuy.motivoBaja ?: "Sin notas"}. Pedigree preservado intacto.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF475569)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(12.dp))

                        // Fila de Atributos Básicos
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Raza", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Text(cuy.raza, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            }
                            Column {
                                Text("Edad", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Text("$edadDias días (${edadDias / 30} meses)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            }
                            Column {
                                Text("Poza actual", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Text(cuy.poza, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            }
                            Column {
                                Text("Último peso", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                val ult = weights.lastOrNull()?.pesoGramos
                                Text(if (ult != null) "${ult.toInt()} g" else "--", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = FarmGreen)
                            }
                        }
                    }
                }
            }

            // 2. Selector de Pestañas (Control de Peso & Gráfica | Árbol Genealógico)
            item {
                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    edgePadding = 0.dp,
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ShowChart, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Curva de Peso & Crecimiento")
                            }
                        },
                        modifier = Modifier.testTag("tab_weight_growth")
                    )
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FamilyRestroom, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Genealogía & Pedigree")
                            }
                        },
                        modifier = Modifier.testTag("tab_pedigree_tree")
                    )
                }
            }

            // CONTENIDO PESTAÑA 0: Control de Peso, Métricas y Gráfica
            if (selectedTabIndex == 0) {
                // Métricas comparativas con la granja
                if (metricas != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = FarmGreenContainer.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Speed, contentDescription = null, tint = FarmGreenDark)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Métricas de Rendimiento y Ganancia",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = FarmGreenDark
                                        )
                                    }
                                    Text(
                                        text = metricas.estadoComparativo,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (metricas.diferenciaPorcentual >= 0) StatusActive else DangerRed
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("Peso Actual", style = MaterialTheme.typography.labelSmall)
                                        Text("${metricas.pesoActualGramos.toInt()} g", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text("Promedio Granja", style = MaterialTheme.typography.labelSmall)
                                        Text("${metricas.promedioGranjaMismaEdad.toInt()} g", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text("Diferencia vs Granja", style = MaterialTheme.typography.labelSmall)
                                        val signo = if (metricas.diferenciaPorcentual >= 0) "+" else ""
                                        Text(
                                            text = "$signo${"%.1f".format(metricas.diferenciaPorcentual)}%",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (metricas.diferenciaPorcentual >= 0) StatusActive else DangerRed
                                        )
                                    }
                                    Column {
                                        Text("Ganancia Diaria (GDP)", style = MaterialTheme.typography.labelSmall)
                                        Text(
                                            text = "+${"%.1f".format(metricas.gananciaDiariaGramos)} g/día",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = FarmGreenDark
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Gráfica de Crecimiento
                item {
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Curva de Crecimiento y Rango Objetivo",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Franja verde: Rango de ganancia óptima INIA",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Button(
                                    onClick = { showAddWeightDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreen),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("btn_add_weight")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pesaje")
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            GrowthChart(
                                registros = weights,
                                fechaNacimiento = cuy.fechaNacimiento,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Historial de Registros de Pesaje
                item {
                    Text(
                        text = "Historial de Pesajes Realizados (${weights.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (weights.isEmpty()) {
                    item {
                        Text(
                            text = "Aún no hay pesajes registrados. Pulsa '+ Pesaje' para comenzar el seguimiento.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(weights.reversed(), key = { it.id }) { reg ->
                        val diasAlPesaje = ((reg.fecha - cuy.fechaNacimiento) / dayMillis).toInt()
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${dateFormat.format(Date(reg.fecha))} • ($diasAlPesaje días de edad)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (reg.notas.isNotBlank()) {
                                        Text(text = reg.notas, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${reg.pesoGramos.toInt()} g",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = FarmGreen
                                    )
                                    IconButton(
                                        onClick = { viewModel.deleteWeightLog(reg.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // CONTENIDO PESTAÑA 1: Genealogía y Pedigree
            if (selectedTabIndex == 1) {
                // Árbol Genealógico
                item {
                    PedigreeTree(
                        cuy = cuy,
                        todosLosCuyes = allCuyes,
                        onSelectCuy = onSelectOtherCuy,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Hermanos y Hermanas conocidos
                item {
                    val hermanos = GeneticCalculator.obtenerHermanos(cuy.id, allCuyes)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Hermanos y Hermanas de Camada (${hermanos.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            if (hermanos.isEmpty()) {
                                Text(
                                    text = "No se registran hermanos de camada compartiendo padre o madre.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    hermanos.forEach { h ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { onSelectOtherCuy(h.id) }
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = if (h.sexo == "Macho") Icons.Default.Male else Icons.Default.Female,
                                                    contentDescription = h.sexo,
                                                    tint = if (h.sexo == "Macho") Color(0xFF2563EB) else Color(0xFFDB2777),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(text = "${h.nombre} (${h.codigo})", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                            }
                                            StatusBadge(estado = h.estado)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Descendencia (Hijos / Hijas)
                item {
                    val hijos = allCuyes.filter { it.madreId == cuy.id || it.padreId == cuy.id }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Descendencia Registrada (${hijos.size} crías)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            if (hijos.isEmpty()) {
                                Text(
                                    text = "Este ejemplar aún no tiene crías registradas en el criadero.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    hijos.forEach { hijo ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { onSelectOtherCuy(hijo.id) }
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = if (hijo.sexo == "Macho") Icons.Default.Male else Icons.Default.Female,
                                                    contentDescription = hijo.sexo,
                                                    tint = if (hijo.sexo == "Macho") Color(0xFF2563EB) else Color(0xFFDB2777),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(text = "${hijo.nombre} (${hijo.codigo})", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                            }
                                            StatusBadge(estado = hijo.estado)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddWeightDialog(
    cuy: CuyEntity,
    onDismiss: () -> Unit,
    onConfirm: (gramos: Float, notas: String) -> Unit
) {
    var pesoText by remember { mutableStateOf("") }
    var notasText by remember { mutableStateOf("Control periódico") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Pesaje de ${cuy.nombre}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = pesoText,
                    onValueChange = { pesoText = it; errorMsg = null },
                    label = { Text("Peso en gramos (g) *") },
                    placeholder = { Text("Ej. 450") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("add_weight_grams_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = notasText,
                    onValueChange = { notasText = it },
                    label = { Text("Notas / Etapa") },
                    placeholder = { Text("Destete, Recría, Antes de monta, etc.") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p = pesoText.toFloatOrNull()
                    if (p == null || p <= 0) {
                        errorMsg = "Ingrese un peso válido en gramos mayor a 0."
                        return@Button
                    }
                    onConfirm(p, notasText.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreen),
                modifier = Modifier.testTag("confirm_add_weight_btn")
            ) {
                Text("Guardar Pesaje")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
