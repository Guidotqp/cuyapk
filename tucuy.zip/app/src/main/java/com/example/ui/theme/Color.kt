package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Farm Theme Colors
val FarmGreen = Color(0xFF16A34A)
val FarmGreenDark = Color(0xFF14532D)
val FarmGreenContainer = Color(0xFFDCFCE7)
val WarmAmber = Color(0xFFD97706)
val DangerRed = Color(0xFFDC2626)

// Status Badges
val StatusActive = Color(0xFF16A34A)
val StatusSold = Color(0xFF2563EB)
val StatusConsumed = Color(0xFFD97706)
val StatusDeceased = Color(0xFF64748B)
val InactiveGray = Color(0xFF94A3B8)

// Sex Colors
val SexMale = Color(0xFF2563EB)
val SexFemale = Color(0xFFDB2777)

// Neutral Colors
val SurfaceLight = Color(0xFFFAFAFA)
val BackgroundLight = Color(0xFFF8FAFC)
