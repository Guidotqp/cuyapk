package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.CuyEntity
import com.example.ui.theme.FarmGreen
import com.example.ui.theme.WarmAmber
import com.example.ui.viewmodel.CuyViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterCuyScreen(
    viewModel: CuyViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allCuyes by viewModel.allCuyes.collectAsState()
    val activeMales by viewModel.activeMales.collectAsState()
    val activeFemales by viewModel.activeFemales.collectAsState()

    val nextNum = (allCuyes.maxOfOrNull { it.id } ?: 0L) + 1
    var codigo by remember { mutableStateOf("CUY-${nextNum.toString().padStart(3, '0')}") }
    var nombre by remember { mutableStateOf("") }
    var sexo by remember { mutableStateOf("Hembra") }
    var raza by remember { mutableStateOf("Perú") }
    var poza by remember { mutableStateOf("Poza 1") }
    var colorPelaje by remember { mutableStateOf("Alazán con blanco") }
    var pesoInicialText by remember { mutableStateOf("320") }
    var notas by remember { mutableStateOf("") }

    // Fecha de nacimiento (por defecto hoy o hace 21 días si es destete)
    var fechaNacimiento by remember { mutableLongStateOf(System.currentTimeMillis() - (21 * 86_400_000L)) }

    // LÓGICA CLAVE: Selección de Hermanos / Hermanas
    var selectedSiblingId by remember { mutableStateOf<Long?>(null) }
    var isParentsLockedBySibling by remember { mutableStateOf(false) }

    var selectedMadreId by remember { mutableStateOf<Long?>(null) }
    var selectedPadreId by remember { mutableStateOf<Long?>(null) }

    var errorMsg by remember { mutableStateOf<String?>(null) }

    // Dropdown states
    var siblingDropdownExpanded by remember { mutableStateOf(false) }
    var razaDropdownExpanded by remember { mutableStateOf(false) }
    var madreDropdownExpanded by remember { mutableStateOf(false) }
    var padreDropdownExpanded by remember { mutableStateOf(false) }

    val razas = listOf("Perú", "Andina", "Inti", "Criollo", "California", "Línea Mejorada")
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Registrar Nuevo Cuy") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Selector de Hermanos / Hermanas (Auto-completar y bloquear padres)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FamilyRestroom,
                                contentDescription = null,
                                tint = FarmGreen
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Genealogía Rápida por Hermano/a",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Al seleccionar un hermano/a de camada, los campos de Madre y Padre se auto-completarán y bloquearán automáticamente.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        ExposedDropdownMenuBox(
                            expanded = siblingDropdownExpanded,
                            onExpandedChange = { siblingDropdownExpanded = !siblingDropdownExpanded }
                        ) {
                            val selectedSibling = allCuyes.find { it.id == selectedSiblingId }
                            val siblingText = if (selectedSibling != null) {
                                "${selectedSibling.nombre} (${selectedSibling.codigo} - ${selectedSibling.sexo})"
                            } else {
                                "Seleccionar hermano/a (opcional)..."
                            }

                            OutlinedTextField(
                                value = siblingText,
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = siblingDropdownExpanded) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isParentsLockedBySibling) Icons.Default.Lock else Icons.Default.Pets,
                                        contentDescription = null,
                                        tint = if (isParentsLockedBySibling) FarmGreen else MaterialTheme.colorScheme.outline
                                    )
                                },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth()
                                    .testTag("sibling_dropdown_input")
                            )

                            ExposedDropdownMenu(
                                expanded = siblingDropdownExpanded,
                                onDismissRequest = { siblingDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Ninguno / Ingreso manual de padres") },
                                    onClick = {
                                        selectedSiblingId = null
                                        isParentsLockedBySibling = false
                                        siblingDropdownExpanded = false
                                    }
                                )
                                allCuyes.forEach { hermanoCandidate ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text("${hermanoCandidate.nombre} (${hermanoCandidate.codigo})")
                                                val madreName = allCuyes.find { it.id == hermanoCandidate.madreId }?.nombre ?: "Sin madre"
                                                val padreName = allCuyes.find { it.id == hermanoCandidate.padreId }?.nombre ?: "Sin padre"
                                                Text(
                                                    text = "Madre: $madreName • Padre: $padreName",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        },
                                        onClick = {
                                            selectedSiblingId = hermanoCandidate.id
                                            selectedMadreId = hermanoCandidate.madreId
                                            selectedPadreId = hermanoCandidate.padreId
                                            isParentsLockedBySibling = true
                                            // Copiar también raza por defecto
                                            raza = hermanoCandidate.raza
                                            siblingDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        if (isParentsLockedBySibling) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = FarmGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Padres bloqueados según el hermano seleccionado",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = FarmGreen
                                    )
                                }
                                OutlinedButton(
                                    onClick = {
                                        isParentsLockedBySibling = false
                                        selectedSiblingId = null
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Desbloquear", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }

            // 2. Progenitores: Madre y Padre
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Selector de Madre
                    ExposedDropdownMenuBox(
                        expanded = madreDropdownExpanded && !isParentsLockedBySibling,
                        onExpandedChange = { if (!isParentsLockedBySibling) madreDropdownExpanded = !madreDropdownExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        val madreObj = allCuyes.find { it.id == selectedMadreId }
                        OutlinedTextField(
                            value = madreObj?.nombre ?: "Sin madre registrada",
                            onValueChange = {},
                            readOnly = true,
                            enabled = !isParentsLockedBySibling,
                            label = { Text("Madre" + if (isParentsLockedBySibling) " (Bloqueada)" else "") },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (isParentsLockedBySibling) Icons.Default.Lock else Icons.Default.Female,
                                    contentDescription = null,
                                    tint = Color(0xFFDB2777)
                                )
                            },
                            trailingIcon = { if (!isParentsLockedBySibling) ExposedDropdownMenuDefaults.TrailingIcon(expanded = madreDropdownExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth().testTag("madre_select_field")
                        )
                        ExposedDropdownMenu(
                            expanded = madreDropdownExpanded,
                            onDismissRequest = { madreDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Ninguna (Fundadora)") },
                                onClick = {
                                    selectedMadreId = null
                                    madreDropdownExpanded = false
                                }
                            )
                            allCuyes.filter { it.sexo == "Hembra" }.forEach { hembra ->
                                DropdownMenuItem(
                                    text = { Text("${hembra.nombre} (${hembra.codigo}) - ${hembra.estado}") },
                                    onClick = {
                                        selectedMadreId = hembra.id
                                        madreDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Selector de Padre
                    ExposedDropdownMenuBox(
                        expanded = padreDropdownExpanded && !isParentsLockedBySibling,
                        onExpandedChange = { if (!isParentsLockedBySibling) padreDropdownExpanded = !padreDropdownExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        val padreObj = allCuyes.find { it.id == selectedPadreId }
                        OutlinedTextField(
                            value = padreObj?.nombre ?: "Sin padre registrado",
                            onValueChange = {},
                            readOnly = true,
                            enabled = !isParentsLockedBySibling,
                            label = { Text("Padre" + if (isParentsLockedBySibling) " (Bloqueado)" else "") },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (isParentsLockedBySibling) Icons.Default.Lock else Icons.Default.Male,
                                    contentDescription = null,
                                    tint = Color(0xFF2563EB)
                                )
                            },
                            trailingIcon = { if (!isParentsLockedBySibling) ExposedDropdownMenuDefaults.TrailingIcon(expanded = padreDropdownExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth().testTag("padre_select_field")
                        )
                        ExposedDropdownMenu(
                            expanded = padreDropdownExpanded,
                            onDismissRequest = { padreDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Ninguno (Fundador)") },
                                onClick = {
                                    selectedPadreId = null
                                    padreDropdownExpanded = false
                                }
                            )
                            allCuyes.filter { it.sexo == "Macho" }.forEach { macho ->
                                DropdownMenuItem(
                                    text = { Text("${macho.nombre} (${macho.codigo}) - ${macho.estado}") },
                                    onClick = {
                                        selectedPadreId = macho.id
                                        padreDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // 3. Datos de Identificación (Código, Nombre, Sexo)
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = codigo,
                        onValueChange = { codigo = it; errorMsg = null },
                        label = { Text("Código de Arete *") },
                        leadingIcon = { Icon(Icons.Default.Tag, contentDescription = null) },
                        modifier = Modifier.weight(1f).testTag("cuy_code_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = nombre,
                        onValueChange = { nombre = it; errorMsg = null },
                        label = { Text("Nombre / Apodo *") },
                        leadingIcon = { Icon(Icons.Default.Pets, contentDescription = null) },
                        modifier = Modifier.weight(1.3f).testTag("cuy_name_input"),
                        singleLine = true
                    )
                }
            }

            // 4. Sexo y Raza
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Sexo selector
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Sexo", style = MaterialTheme.typography.labelSmall)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Button(
                                onClick = { sexo = "Hembra" },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (sexo == "Hembra") Color(0xFFDB2777) else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (sexo == "Hembra") Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.weight(1f).testTag("sex_female_btn")
                            ) {
                                Text("Hembra")
                            }
                            Button(
                                onClick = { sexo = "Macho" },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (sexo == "Macho") Color(0xFF2563EB) else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (sexo == "Macho") Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.weight(1f).testTag("sex_male_btn")
                            ) {
                                Text("Macho")
                            }
                        }
                    }

                    // Raza selector
                    ExposedDropdownMenuBox(
                        expanded = razaDropdownExpanded,
                        onExpandedChange = { razaDropdownExpanded = !razaDropdownExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = raza,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Raza") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = razaDropdownExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth().testTag("raza_select_field")
                        )
                        ExposedDropdownMenu(
                            expanded = razaDropdownExpanded,
                            onDismissRequest = { razaDropdownExpanded = false }
                        ) {
                            razas.forEach { r ->
                                DropdownMenuItem(
                                    text = { Text(r) },
                                    onClick = {
                                        raza = r
                                        razaDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // 5. Poza y Color de Pelaje
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = poza,
                        onValueChange = { poza = it },
                        label = { Text("Poza / Jaula") },
                        leadingIcon = { Icon(Icons.Default.MeetingRoom, contentDescription = null) },
                        modifier = Modifier.weight(1f).testTag("poza_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = colorPelaje,
                        onValueChange = { colorPelaje = it },
                        label = { Text("Color de Pelaje") },
                        leadingIcon = { Icon(Icons.Default.Palette, contentDescription = null) },
                        modifier = Modifier.weight(1f).testTag("color_input"),
                        singleLine = true
                    )
                }
            }

            // 6. Peso Inicial
            item {
                OutlinedTextField(
                    value = pesoInicialText,
                    onValueChange = { pesoInicialText = it },
                    label = { Text("Peso Inicial (gramos)") },
                    supportingText = { Text("Se registrará en el historial de crecimiento del cuy") },
                    leadingIcon = { Icon(Icons.Default.Balance, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("initial_weight_input"),
                    singleLine = true
                )
            }

            // 7. Notas
            item {
                OutlinedTextField(
                    value = notas,
                    onValueChange = { notas = it },
                    label = { Text("Notas y observaciones") },
                    placeholder = { Text("Características fenotípicas, temperamento...") },
                    modifier = Modifier.fillMaxWidth().testTag("notes_input"),
                    minLines = 2,
                    maxLines = 3
                )
            }

            if (errorMsg != null) {
                item {
                    Text(
                        text = errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            // 8. Botón Guardar
            item {
                Button(
                    onClick = {
                        if (codigo.isBlank()) {
                            errorMsg = "El código es obligatorio."
                            return@Button
                        }
                        if (nombre.isBlank()) {
                            errorMsg = "El nombre o apodo es obligatorio."
                            return@Button
                        }

                        val pesoGramos = pesoInicialText.toFloatOrNull()
                        val nuevoCuy = CuyEntity(
                            codigo = codigo.trim(),
                            nombre = nombre.trim(),
                            sexo = sexo,
                            raza = raza,
                            fechaNacimiento = fechaNacimiento,
                            madreId = selectedMadreId,
                            padreId = selectedPadreId,
                            poza = poza.trim().ifEmpty { "Poza General" },
                            estado = "Activo",
                            colorPelaje = colorPelaje.trim(),
                            notas = notas.trim()
                        )

                        viewModel.insertCuy(nuevoCuy, initialWeightGrams = pesoGramos) {
                            onNavigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreen),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("submit_register_cuy_button")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Guardar y Registrar Cuy", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
