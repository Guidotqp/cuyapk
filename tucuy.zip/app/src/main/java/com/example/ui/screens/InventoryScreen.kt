package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.CamadaEntity
import com.example.data.model.CuyEntity
import com.example.ui.components.BatchWeaningDialog
import com.example.ui.components.DashboardBanners
import com.example.ui.components.StatusBadge
import com.example.ui.theme.FarmGreen
import com.example.ui.theme.FarmGreenContainer
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.WarmAmber
import com.example.ui.viewmodel.CuyViewModel

@Composable
fun InventoryScreen(
    viewModel: CuyViewModel,
    onSelectCuy: (Long) -> Unit,
    onNavigateRegister: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allCuyes by viewModel.allCuyes.collectAsState()
    val allWeightLogs by viewModel.allWeightLogs.collectAsState()
    val weaningAlerts by viewModel.weaningAlerts.collectAsState()
    val birthAlerts by viewModel.birthAlerts.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("Todos") }
    var selectedSexFilter by remember { mutableStateOf<String?>(null) }

    // Dialogo de destete rápido
    var weaningModalCamada by remember { mutableStateOf<CamadaEntity?>(null) }
    var weaningModalMadreNombre by remember { mutableStateOf("") }

    val dayMillis = 86_400_000L
    val now = System.currentTimeMillis()

    // Filtros de estado
    val filteredCuyes = allCuyes.filter { cuy ->
        val matchesSearch = cuy.nombre.contains(searchQuery, ignoreCase = true) ||
                cuy.codigo.contains(searchQuery, ignoreCase = true) ||
                cuy.raza.contains(searchQuery, ignoreCase = true) ||
                cuy.poza.contains(searchQuery, ignoreCase = true)

        val matchesStatus = when (selectedFilter) {
            "Todos" -> true
            "Activos" -> cuy.estado == "Activo"
            "Vendidos" -> cuy.estado == "Vendido"
            "Consumidos" -> cuy.estado == "Consumido"
            "Fallecidos" -> cuy.estado == "Fallecido"
            else -> true
        }

        val matchesSex = selectedSexFilter == null || cuy.sexo == selectedSexFilter

        matchesSearch && matchesStatus && matchesSex
    }

    // Modal de destete rápido si se abre
    weaningModalCamada?.let { camada ->
        BatchWeaningDialog(
            camada = camada,
            madreNombre = weaningModalMadreNombre,
            onDismiss = { weaningModalCamada = null },
            onConfirm = { m, h, pozaM, pozaH, peso ->
                viewModel.performBatchWeaning(
                    camada = camada,
                    machos = m,
                    hembras = h,
                    pozaMachos = pozaM,
                    pozaHembras = pozaH,
                    fechaDestete = now,
                    pesoPromedioDesteteGramos = peso,
                    onComplete = { weaningModalCamada = null }
                )
            }
        )
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            // CLAVE: Gran padding inferior (100dp) para asegurar 100% de visibilidad sobre la barra inferior
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // 1. Hero Banner y Encabezado de la Granja
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.cuy_banner),
                        contentDescription = "Granja de Cuyes",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f))
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Criadero CuyManager",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Control de Reproducción, Pesaje y Genealogía",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }

            // 2. Notificaciones Inteligentes (Destete 21 días y Parto 62+ días)
            item {
                DashboardBanners(
                    weaningAlerts = weaningAlerts,
                    birthAlerts = birthAlerts,
                    onDismissAlert = { viewModel.dismissAlert(it) },
                    onTapWeaning = { camada, madreNombre ->
                        weaningModalCamada = camada
                        weaningModalMadreNombre = madreNombre
                    },
                    onTapBirth = { madreId -> onSelectCuy(madreId) }
                )
            }

            // 3. Resumen Rápido del Rebaño
            item {
                val totalActivos = allCuyes.count { it.estado == "Activo" }
                val machosActivos = allCuyes.count { it.estado == "Activo" && it.sexo == "Macho" }
                val hembrasActivas = allCuyes.count { it.estado == "Activo" && it.sexo == "Hembra" }
                val historicosBaja = allCuyes.count { it.estado != "Activo" }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HerdStatCard(titulo = "Activos", valor = "$totalActivos", color = FarmGreen, modifier = Modifier.weight(1f))
                    HerdStatCard(titulo = "Machos", valor = "$machosActivos", color = Color(0xFF2563EB), modifier = Modifier.weight(1f))
                    HerdStatCard(titulo = "Hembras", valor = "$hembrasActivas", color = Color(0xFFDB2777), modifier = Modifier.weight(1f))
                    HerdStatCard(titulo = "Bajas", valor = "$historicosBaja", color = Color(0xFF64748B), modifier = Modifier.weight(1f))
                }
            }

            // 4. Barra de Búsqueda
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Buscar por código, nombre, raza, poza...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Limpiar")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("inventory_search_field")
                )
            }

            // 5. Filtros Rápidos (Chips)
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    val statusChips = listOf("Todos", "Activos", "Vendidos", "Consumidos", "Fallecidos")
                    items(statusChips) { filtro ->
                        FilterChip(
                            selected = selectedFilter == filtro,
                            onClick = { selectedFilter = filtro },
                            label = { Text(filtro) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenContainer,
                                selectedLabelColor = FarmGreenDark
                            ),
                            modifier = Modifier.testTag("filter_chip_$filtro")
                        )
                    }

                    item {
                        FilterChip(
                            selected = selectedSexFilter == "Macho",
                            onClick = { selectedSexFilter = if (selectedSexFilter == "Macho") null else "Macho" },
                            label = { Text("Solo Machos") },
                            leadingIcon = { Icon(Icons.Default.Male, contentDescription = null, tint = Color(0xFF2563EB)) }
                        )
                    }

                    item {
                        FilterChip(
                            selected = selectedSexFilter == "Hembra",
                            onClick = { selectedSexFilter = if (selectedSexFilter == "Hembra") null else "Hembra" },
                            label = { Text("Solo Hembras") },
                            leadingIcon = { Icon(Icons.Default.Female, contentDescription = null, tint = Color(0xFFDB2777)) }
                        )
                    }
                }
            }

            // 6. Lista de Cuyes
            if (filteredCuyes.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Pets,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No se encontraron cuyes con los filtros seleccionados.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(filteredCuyes, key = { it.id }) { cuy ->
                    val pesos = allWeightLogs.filter { it.cuyId == cuy.id }
                    val ultimoPeso = pesos.maxByOrNull { it.fecha }?.pesoGramos
                    val edadDias = ((now - cuy.fechaNacimiento) / dayMillis).toInt().coerceAtLeast(0)

                    CuyCardItem(
                        cuy = cuy,
                        ultimoPesoGramos = ultimoPeso,
                        edadDias = edadDias,
                        onClick = { onSelectCuy(cuy.id) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("cuy_item_${cuy.id}")
                    )
                }
            }
        }

        // Botón Flotante para Agregar Rápido
        FloatingActionButton(
            onClick = onNavigateRegister,
            containerColor = FarmGreen,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 96.dp, end = 20.dp)
                .testTag("fab_register_cuy")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Registrar nuevo cuy")
        }
    }
}

@Composable
fun CuyCardItem(
    cuy: CuyEntity,
    ultimoPesoGramos: Float?,
    edadDias: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.5.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icono de sexo / avatar
            val esMacho = cuy.sexo == "Macho"
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(
                        if (esMacho) Color(0xFFEFF6FF) else Color(0xFFFDF2F8),
                        RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (esMacho) Icons.Default.Male else Icons.Default.Female,
                    contentDescription = cuy.sexo,
                    tint = if (esMacho) Color(0xFF2563EB) else Color(0xFFDB2777),
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Datos del cuy
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = cuy.nombre,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    StatusBadge(estado = cuy.estado)
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = cuy.codigo,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = FarmGreen
                    )
                    Text(
                        text = " • Raza ${cuy.raza} • ${cuy.poza}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val etapa = when {
                        edadDias <= 21 -> "Lactante (${edadDias}d)"
                        edadDias <= 60 -> "Recría (${edadDias}d)"
                        edadDias <= 90 -> "Engorde (${edadDias}d)"
                        else -> "Adulto (${edadDias}d)"
                    }
                    Text(
                        text = etapa,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Text(
                        text = if (ultimoPesoGramos != null) "${ultimoPesoGramos.toInt()} g" else "Sin pesaje",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (ultimoPesoGramos != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                    )
                }
            }
        }
    }
}

@Composable
fun HerdStatCard(
    titulo: String,
    valor: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.1f)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = valor,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = titulo,
                style = TextStyle(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
