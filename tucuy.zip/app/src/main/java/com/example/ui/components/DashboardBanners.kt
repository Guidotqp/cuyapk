package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BabyChangingStation
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.PregnantWoman
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CamadaEntity
import com.example.ui.theme.FarmGreen
import com.example.ui.theme.WarmAmber
import com.example.ui.viewmodel.AlertaDestete
import com.example.ui.viewmodel.AlertaParto

@Composable
fun DashboardBanners(
    weaningAlerts: List<AlertaDestete>,
    birthAlerts: List<AlertaParto>,
    onDismissAlert: (String) -> Unit,
    onTapWeaning: (CamadaEntity, String) -> Unit,
    onTapBirth: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    if (weaningAlerts.isEmpty() && birthAlerts.isEmpty()) return

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Alertas de Destete (21 Días)
        weaningAlerts.forEach { alerta ->
            val key = "destete_${alerta.camada.id}"
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onTapWeaning(alerta.camada, alerta.madreNombre) }
                    .testTag("banner_weaning_${alerta.camada.id}"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(WarmAmber, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pets,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "¡Alerta de Destete (21 días)!",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E)
                            )
                        }
                        Text(
                            text = alerta.mensaje,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF78350F)
                        )
                        Text(
                            text = "Toca aquí para separar crías por sexo y reubicar pozas",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFB45309)
                        )
                    }

                    IconButton(
                        onClick = { onDismissAlert(key) },
                        modifier = Modifier.size(28.dp).testTag("dismiss_weaning_${alerta.camada.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Descartar alerta",
                            tint = Color(0xFF92400E),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Alertas de Parto Próximo (62+ Días de gestación sobre 67 días promedio)
        birthAlerts.forEach { alerta ->
            val key = "parto_${alerta.cruce.id}"
            val bgColor = if (alerta.esRetraso) Color(0xFFFEE2E2) else Color(0xFFE0F2FE)
            val iconColor = if (alerta.esRetraso) Color(0xFFDC2626) else Color(0xFF0284C7)
            val textColor = if (alerta.esRetraso) Color(0xFF991B1B) else Color(0xFF075985)

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onTapBirth(alerta.cruce.hembraId) }
                    .testTag("banner_birth_${alerta.cruce.id}"),
                colors = CardDefaults.cardColors(containerColor = bgColor),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(iconColor, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationImportant,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (alerta.esRetraso) "Parto con Días de Retraso" else "Parto Próximo (Gestación)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                        Text(
                            text = alerta.mensaje,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = textColor
                        )
                        Text(
                            text = "Revisar nido y suministrar forraje verde fresco en ${alerta.cruce.poza}",
                            style = MaterialTheme.typography.labelSmall,
                            color = textColor.copy(alpha = 0.85f)
                        )
                    }

                    IconButton(
                        onClick = { onDismissAlert(key) },
                        modifier = Modifier.size(28.dp).testTag("dismiss_birth_${alerta.cruce.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Descartar alerta",
                            tint = textColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
