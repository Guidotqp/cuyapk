package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CuyEntity
import com.example.ui.theme.FarmGreen
import com.example.ui.theme.InactiveGray
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusConsumed
import com.example.ui.theme.StatusDeceased
import com.example.ui.theme.StatusSold
import com.example.ui.theme.WarmAmber

/**
 * Visualizador del Árbol Genealógico / Pedigree (3 Generaciones)
 * Garantiza que los registros dados de baja permanezcan intactos en la genealogía.
 */
@Composable
fun PedigreeTree(
    cuy: CuyEntity,
    todosLosCuyes: List<CuyEntity>,
    onSelectCuy: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val map = todosLosCuyes.associateBy { it.id }

    val padre = cuy.padreId?.let { map[it] }
    val madre = cuy.madreId?.let { map[it] }

    val abueloPat = padre?.padreId?.let { map[it] }
    val abuelaPat = padre?.madreId?.let { map[it] }

    val abueloMat = madre?.padreId?.let { map[it] }
    val abuelaMat = madre?.madreId?.let { map[it] }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Genealogía y Pedigree Oficial",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "3 Generaciones",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Generación 1: Abuelos (4 casillas)
        Text(
            text = "1ª Gen: Abuelos / Fundadores",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PedigreeMiniCard(animal = abueloPat, rol = "Abuelo Pat.", esMacho = true, modifier = Modifier.weight(1f), onClick = onSelectCuy)
            PedigreeMiniCard(animal = abuelaPat, rol = "Abuela Pat.", esMacho = false, modifier = Modifier.weight(1f), onClick = onSelectCuy)
            PedigreeMiniCard(animal = abueloMat, rol = "Abuelo Mat.", esMacho = true, modifier = Modifier.weight(1f), onClick = onSelectCuy)
            PedigreeMiniCard(animal = abuelaMat, rol = "Abuela Mat.", esMacho = false, modifier = Modifier.weight(1f), onClick = onSelectCuy)
        }

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        Spacer(modifier = Modifier.height(10.dp))

        // Generación 2: Padres (2 casillas)
        Text(
            text = "2ª Gen: Progenitores Directos",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PedigreeMiniCard(animal = padre, rol = "Padre Directo", esMacho = true, modifier = Modifier.weight(1f), onClick = onSelectCuy)
            PedigreeMiniCard(animal = madre, rol = "Madre Directa", esMacho = false, modifier = Modifier.weight(1f), onClick = onSelectCuy)
        }

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        Spacer(modifier = Modifier.height(10.dp))

        // Generación 3: El Cuy actual
        Text(
            text = "3ª Gen: Ejemplar Evaluado",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(FarmGreen.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (cuy.sexo == "Macho") Icons.Default.Male else Icons.Default.Female,
                            contentDescription = cuy.sexo,
                            tint = if (cuy.sexo == "Macho") Color(0xFF2563EB) else Color(0xFFDB2777)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = cuy.nombre,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${cuy.codigo} • Raza ${cuy.raza} • ${cuy.poza}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                StatusBadge(estado = cuy.estado)
            }
        }
    }
}

@Composable
fun PedigreeMiniCard(
    animal: CuyEntity?,
    rol: String,
    esMacho: Boolean,
    modifier: Modifier = Modifier,
    onClick: (Long) -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(enabled = animal != null) { animal?.let { onClick(it.id) } },
        color = if (animal != null) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(8.dp),
        shadowElevation = if (animal != null) 1.dp else 0.dp
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = rol,
                style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                color = if (esMacho) Color(0xFF1D4ED8) else Color(0xFFBE185D),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))

            if (animal != null) {
                Text(
                    text = animal.nombre,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = animal.codigo,
                    style = TextStyle(fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant),
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                // Badge de estado compacto
                StatusBadgeCompact(estado = animal.estado)
            } else {
                Text(
                    text = "No registrado",
                    style = TextStyle(fontSize = 9.sp, color = MaterialTheme.colorScheme.outline),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "(Fundador)",
                    style = TextStyle(fontSize = 8.sp, color = MaterialTheme.colorScheme.outline),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun StatusBadge(estado: String) {
    val bgColor = when (estado) {
        "Activo" -> Color(0xFFDCFCE7)
        "Vendido" -> Color(0xFFDBEAFE)
        "Consumido" -> Color(0xFFFEF3C7)
        "Fallecido" -> Color(0xFFFEE2E2)
        else -> Color(0xFFF1F5F9)
    }
    val textColor = when (estado) {
        "Activo" -> StatusActive
        "Vendido" -> StatusSold
        "Consumido" -> StatusConsumed
        "Fallecido" -> StatusDeceased
        else -> InactiveGray
    }
    val label = when (estado) {
        "Activo" -> "Activo"
        "Vendido" -> "Vendido"
        "Consumido" -> "Consumido"
        "Fallecido" -> "Fallecido"
        else -> estado
    }

    Box(
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

@Composable
fun StatusBadgeCompact(estado: String) {
    val bgColor = when (estado) {
        "Activo" -> Color(0xFFDCFCE7)
        "Vendido" -> Color(0xFFDBEAFE)
        "Consumido" -> Color(0xFFFEF3C7)
        "Fallecido" -> Color(0xFFFEE2E2)
        else -> Color(0xFFF1F5F9)
    }
    val textColor = when (estado) {
        "Activo" -> StatusActive
        "Vendido" -> StatusSold
        "Consumido" -> StatusConsumed
        "Fallecido" -> StatusDeceased
        else -> InactiveGray
    }
    val label = when (estado) {
        "Activo" -> "Activo"
        "Vendido" -> "Vendido"
        "Consumido" -> "Consumo"
        "Fallecido" -> "Baja"
        else -> estado
    }

    Box(
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(4.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
    ) {
        Text(
            text = label,
            style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Bold),
            color = textColor
        )
    }
}
