package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BabyChangingStation
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CamadaEntity
import com.example.data.model.CruceEntity
import com.example.data.model.CuyEntity
import com.example.ui.components.BatchWeaningDialog
import com.example.ui.theme.FarmGreen
import com.example.ui.theme.FarmGreenContainer
import com.example.ui.theme.WarmAmber
import com.example.ui.viewmodel.CuyViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BreedingManagementScreen(
    viewModel: CuyViewModel,
    onSelectCuy: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val allCuyes by viewModel.allCuyes.collectAsState()
    val activeMales by viewModel.activeMales.collectAsState()
    val activeFemales by viewModel.activeFemales.collectAsState()
    val allCruces by viewModel.allCruces.collectAsState()
    val allCamadas by viewModel.allCamadas.collectAsState()
    val weaningAlerts by viewModel.weaningAlerts.collectAsState()
    val birthAlerts by viewModel.birthAlerts.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Destetes (21d)", "Gestaciones (67d)", "Camadas", "Cruces")

    // Modales
    var showWeaningDialogForCamada by remember { mutableStateOf<CamadaEntity?>(null) }
    var showNewMatingDialog by remember { mutableStateOf(false) }
    var showNewBirthDialog by remember { mutableStateOf(false) }

    val cuyMap = remember(allCuyes) { allCuyes.associateBy { it.id } }
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val dayMillis = 86_400_000L
    val now = System.currentTimeMillis()

    // Dialogo de destete rápido
    showWeaningDialogForCamada?.let { camada ->
        val madreNombre = cuyMap[camada.madreId]?.nombre ?: "Madre #${camada.madreId}"
        BatchWeaningDialog(
            camada = camada,
            madreNombre = madreNombre,
            onDismiss = { showWeaningDialogForCamada = null },
            onConfirm = { m, h, pozaM, pozaH, peso ->
                viewModel.performBatchWeaning(
                    camada = camada,
                    machos = m,
                    hembras = h,
                    pozaMachos = pozaM,
                    pozaHembras = pozaH,
                    fechaDestete = now,
                    pesoPromedioDesteteGramos = peso,
                    onComplete = { showWeaningDialogForCamada = null }
                )
            }
        )
    }

    // Modal nuevo cruce/monta
    if (showNewMatingDialog) {
        NewMatingDialog(
            males = activeMales,
            females = activeFemales,
            onDismiss = { showNewMatingDialog = false },
            onConfirm = { mId, fId, poza, notas ->
                viewModel.registerCruce(mId, fId, now, poza, notas)
                showNewMatingDialog = false
            }
        )
    }

    // Modal nuevo parto
    if (showNewBirthDialog) {
        NewBirthDialog(
            males = allCuyes.filter { it.sexo == "Macho" },
            females = activeFemales,
            activeGestations = allCruces.filter { it.estado == "En gestación" },
            onDismiss = { showNewBirthDialog = false },
            onConfirm = { cruceId, mId, pId, criasV, criasM, notas ->
                viewModel.registerBirth(cruceId, mId, pId, now, criasV, criasM, notas)
                showNewBirthDialog = false
            }
        )
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Encabezado
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(top = 16.dp, start = 16.dp, end = 16.dp)) {
                    Text(
                        text = "Gestión Reproductiva y Camadas",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Ciclo reproductivo: Gestación (67d) • Destete rápido (21d)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    ScrollableTabRow(
                        selectedTabIndex = selectedTab,
                        edgePadding = 0.dp,
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        tabs.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                text = { Text(title) }
                            )
                        }
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // TAB 0: DESTETES (21 DÍAS)
                if (selectedTab == 0) {
                    val camadasPendientes = allCamadas.filter { it.estadoDestete == "Pendiente" }
                    item {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = WarmAmber)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Regla de Oro del Destete a los 21 días",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF92400E)
                                    )
                                    Text(
                                        text = "A los 21 días las crías deben separarse por sexo para evitar que los gazapos machos precoces cubran a sus madres o hermanas.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF78350F)
                                    )
                                }
                            }
                        }
                    }

                    if (camadasPendientes.isEmpty()) {
                        item {
                            Text(
                                text = "No hay camadas pendientes de destete en este momento.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    } else {
                        items(camadasPendientes, key = { it.id }) { camada ->
                            val madre = cuyMap[camada.madreId]
                            val padre = camada.padreId?.let { cuyMap[it] }
                            val diasEdad = ((now - camada.fechaParto) / dayMillis).toInt().coerceAtLeast(0)
                            val esListo21 = diasEdad >= 21

                            ElevatedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.elevatedCardColors(
                                    containerColor = if (esListo21) Color(0xFFFFFBEB) else MaterialTheme.colorScheme.surface
                                )
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Camada #${camada.id} • Madre: ${madre?.nombre ?: "Desconocida"}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Surface(
                                            color = if (esListo21) Color(0xFFFDE68A) else Color(0xFFE2E8F0),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(
                                                text = if (esListo21) "¡LISTA PARA DESTETE!" else "En lactancia",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (esListo21) Color(0xFF92400E) else Color(0xFF475569),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Edad: $diasEdad días • Nacimiento: ${dateFormat.format(Date(camada.fechaParto))} • Crías vivas: ${camada.criasVivas}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (padre != null) {
                                        Text(
                                            text = "Padre: ${padre.nombre} (${padre.codigo})",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Button(
                                        onClick = { showWeaningDialogForCamada = camada },
                                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreen),
                                        modifier = Modifier.fillMaxWidth().testTag("wean_litter_button_${camada.id}")
                                    ) {
                                        Icon(Icons.Default.BabyChangingStation, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Realizar Destete Rápido por Lote")
                                    }
                                }
                            }
                        }
                    }
                }

                // TAB 1: GESTACIONES (67 DÍAS)
                if (selectedTab == 1) {
                    val gestacionesActivas = allCruces.filter { it.estado == "En gestación" }
                    item {
                        Surface(
                            color = Color(0xFFE0F2FE),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Color(0xFF0284C7))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Monitoreo de Gestación (Promedio 67 días)",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0369A1)
                                    )
                                    Text(
                                        text = "El período de gestación del cuy oscila entre 65 y 70 días. Las alertas de preparación de nido inician a partir del día 62.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF0C4A6E)
                                    )
                                }
                            }
                        }
                    }

                    if (gestacionesActivas.isEmpty()) {
                        item {
                            Text(
                                text = "No hay cruces en estado de gestación activa.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    } else {
                        items(gestacionesActivas, key = { it.id }) { cruce ->
                            val madre = cuyMap[cruce.hembraId]
                            val padre = cuyMap[cruce.machoId]
                            val diasGestacion = ((now - cruce.fechaMonta) / dayMillis).toInt().coerceAtLeast(0)
                            val diasRestantes = 67 - diasGestacion

                            ElevatedCard(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Hembra: ${madre?.nombre ?: "#${cruce.hembraId}"}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        val estadoColor = if (diasGestacion >= 62) Color(0xFFDC2626) else FarmGreen
                                        Text(
                                            text = "Día $diasGestacion / 67",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = estadoColor
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Macho: ${padre?.nombre ?: "#${cruce.machoId}"} • Poza: ${cruce.poza}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Monta: ${dateFormat.format(Date(cruce.fechaMonta))} • Fecha estimada parto: ${dateFormat.format(Date(cruce.fechaPartoEstimada))}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    if (diasRestantes <= 5 && diasRestantes >= 0) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Surface(color = Color(0xFFFEF3C7), shape = RoundedCornerShape(6.dp)) {
                                            Text(
                                                text = "¡Alerta! Parto inminente en aprox. $diasRestantes días. Acondicionar nido y forraje.",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFF92400E),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    } else if (diasRestantes < 0) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Surface(color = Color(0xFFFEE2E2), shape = RoundedCornerShape(6.dp)) {
                                            Text(
                                                text = "Atención: ${-diasRestantes} días posteriores a la fecha estimada.",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFF991B1B),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = { showNewBirthDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreen),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Registrar Nacimiento / Parto de esta hembra")
                                    }
                                }
                            }
                        }
                    }
                }

                // TAB 2: TODAS LAS CAMADAS HISTÓRICAS
                if (selectedTab == 2) {
                    items(allCamadas, key = { it.id }) { camada ->
                        val madre = cuyMap[camada.madreId]
                        val padre = camada.padreId?.let { cuyMap[it] }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Camada #${camada.id} (${madre?.nombre ?: "Madre #${camada.madreId}"})",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Surface(
                                        color = if (camada.estadoDestete == "Destetado") Color(0xFFDCFCE7) else Color(0xFFFEF3C7),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(
                                            text = camada.estadoDestete,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (camada.estadoDestete == "Destetado") FarmGreen else Color(0xFF92400E),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "Nacidas: ${camada.criasVivas} vivas (${camada.machos} machos, ${camada.hembras} hembras)",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = "Parto: ${dateFormat.format(Date(camada.fechaParto))} • Poza: ${camada.pozaDestete ?: "No reubicada"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // TAB 3: REGISTRO DE MONTAS Y CRUCES
                if (selectedTab == 3) {
                    items(allCruces, key = { it.id }) { cruce ->
                        val madre = cuyMap[cruce.hembraId]
                        val padre = cuyMap[cruce.machoId]

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Cruce: ${padre?.nombre ?: "Macho"} x ${madre?.nombre ?: "Hembra"}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = cruce.estado,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (cruce.estado == "En gestación") Color(0xFF0284C7) else FarmGreen
                                    )
                                }
                                Text(
                                    text = "Fecha de monta: ${dateFormat.format(Date(cruce.fechaMonta))} • Poza: ${cruce.poza}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Acciones flotantes
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 96.dp, end = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { showNewBirthDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = WarmAmber),
                modifier = Modifier.testTag("btn_register_birth")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Nuevo Parto")
            }
            Button(
                onClick = { showNewMatingDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreen),
                modifier = Modifier.testTag("btn_register_mating")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Nueva Monta")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewMatingDialog(
    males: List<CuyEntity>,
    females: List<CuyEntity>,
    onDismiss: () -> Unit,
    onConfirm: (machoId: Long, hembraId: Long, poza: String, notas: String) -> Unit
) {
    var selectedMachoId by remember { mutableStateOf(males.firstOrNull()?.id) }
    var selectedHembraId by remember { mutableStateOf(females.firstOrNull()?.id) }
    var pozaText by remember { mutableStateOf("Poza Reproductores 1") }
    var notasText by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    var expandedM by remember { mutableStateOf(false) }
    var expandedH by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Nuevo Cruce / Monta") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Macho
                ExposedDropdownMenuBox(expanded = expandedM, onExpandedChange = { expandedM = !expandedM }) {
                    val mObj = males.find { it.id == selectedMachoId }
                    OutlinedTextField(
                        value = mObj?.let { "${it.nombre} (${it.codigo})" } ?: "Seleccionar Macho...",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Macho Reproductor *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedM) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expandedM, onDismissRequest = { expandedM = false }) {
                        males.forEach { m ->
                            DropdownMenuItem(
                                text = { Text("${m.nombre} (${m.codigo} - Raza ${m.raza})") },
                                onClick = { selectedMachoId = m.id; expandedM = false }
                            )
                        }
                    }
                }

                // Hembra
                ExposedDropdownMenuBox(expanded = expandedH, onExpandedChange = { expandedH = !expandedH }) {
                    val hObj = females.find { it.id == selectedHembraId }
                    OutlinedTextField(
                        value = hObj?.let { "${it.nombre} (${it.codigo})" } ?: "Seleccionar Hembra...",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Hembra Reproductora *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedH) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expandedH, onDismissRequest = { expandedH = false }) {
                        females.forEach { f ->
                            DropdownMenuItem(
                                text = { Text("${f.nombre} (${f.codigo} - Raza ${f.raza})") },
                                onClick = { selectedHembraId = f.id; expandedH = false }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = pozaText,
                    onValueChange = { pozaText = it },
                    label = { Text("Poza de Monta / Empadre") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notasText,
                    onValueChange = { notasText = it },
                    label = { Text("Notas (Opcional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedMachoId == null || selectedHembraId == null) {
                        errorMsg = "Seleccione un macho y una hembra."
                        return@Button
                    }
                    onConfirm(selectedMachoId!!, selectedHembraId!!, pozaText.trim(), notasText.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreen)
            ) {
                Text("Guardar Cruce")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewBirthDialog(
    males: List<CuyEntity>,
    females: List<CuyEntity>,
    activeGestations: List<CruceEntity>,
    onDismiss: () -> Unit,
    onConfirm: (cruceId: Long?, madreId: Long, padreId: Long?, criasVivas: Int, criasMuertas: Int, notas: String) -> Unit
) {
    var selectedMadreId by remember { mutableStateOf(females.firstOrNull()?.id) }
    var selectedPadreId by remember { mutableStateOf(males.firstOrNull()?.id) }
    var selectedCruceId by remember { mutableStateOf<Long?>(null) }
    var criasVivasText by remember { mutableStateOf("3") }
    var criasMuertasText by remember { mutableStateOf("0") }
    var notasText by remember { mutableStateOf("Nacimiento normal sin complicaciones") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    var expandedM by remember { mutableStateOf(false) }
    var expandedP by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Nuevo Parto / Camada") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Madre
                ExposedDropdownMenuBox(expanded = expandedM, onExpandedChange = { expandedM = !expandedM }) {
                    val mObj = females.find { it.id == selectedMadreId }
                    OutlinedTextField(
                        value = mObj?.let { "${it.nombre} (${it.codigo})" } ?: "Seleccionar Madre...",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Madre Parida *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedM) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expandedM, onDismissRequest = { expandedM = false }) {
                        females.forEach { f ->
                            DropdownMenuItem(
                                text = { Text("${f.nombre} (${f.codigo})") },
                                onClick = {
                                    selectedMadreId = f.id
                                    // Asociar cruce si existe
                                    val cruce = activeGestations.find { it.hembraId == f.id }
                                    if (cruce != null) {
                                        selectedCruceId = cruce.id
                                        selectedPadreId = cruce.machoId
                                    }
                                    expandedM = false
                                }
                            )
                        }
                    }
                }

                // Padre
                ExposedDropdownMenuBox(expanded = expandedP, onExpandedChange = { expandedP = !expandedP }) {
                    val pObj = males.find { it.id == selectedPadreId }
                    OutlinedTextField(
                        value = pObj?.let { "${it.nombre} (${it.codigo})" } ?: "Seleccionar Padre...",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Padre de la camada (Opcional)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedP) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expandedP, onDismissRequest = { expandedP = false }) {
                        DropdownMenuItem(
                            text = { Text("Desconocido / Sin registrar") },
                            onClick = { selectedPadreId = null; expandedP = false }
                        )
                        males.forEach { m ->
                            DropdownMenuItem(
                                text = { Text("${m.nombre} (${m.codigo})") },
                                onClick = { selectedPadreId = m.id; expandedP = false }
                            )
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = criasVivasText,
                        onValueChange = { criasVivasText = it },
                        label = { Text("Crías vivas *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = criasMuertasText,
                        onValueChange = { criasMuertasText = it },
                        label = { Text("Crías muertas") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = notasText,
                    onValueChange = { notasText = it },
                    label = { Text("Notas del parto") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val v = criasVivasText.toIntOrNull() ?: -1
                    val m = criasMuertasText.toIntOrNull() ?: 0
                    if (selectedMadreId == null) {
                        errorMsg = "Seleccione a la madre."
                        return@Button
                    }
                    if (v < 0) {
                        errorMsg = "Ingrese un número válido de crías vivas."
                        return@Button
                    }
                    onConfirm(selectedCruceId, selectedMadreId!!, selectedPadreId, v, m, notasText.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreen)
            ) {
                Text("Registrar Parto")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
