package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.CuyDatabase
import com.example.data.model.CamadaEntity
import com.example.data.model.CruceEntity
import com.example.data.model.CuyEntity
import com.example.data.model.RegistroPesoEntity
import com.example.data.repository.CuyRepository
import com.example.logic.AnalisisCruce
import com.example.logic.GeneticCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// Modelos para las Notificaciones Inteligentes
data class AlertaDestete(
    val camada: CamadaEntity,
    val madreNombre: String,
    val diasEdad: Int,
    val mensaje: String
)

data class AlertaParto(
    val cruce: CruceEntity,
    val madreNombre: String,
    val diasGestacion: Int,
    val diasRestantes: Int,
    val mensaje: String,
    val esRetraso: Boolean
)

data class MetricasCrecimiento(
    val pesoActualGramos: Float,
    val promedioGranjaMismaEdad: Float,
    val diferenciaPorcentual: Float,
    val gananciaDiariaGramos: Float, // g/día
    val estadoComparativo: String // "Superior al promedio", "En promedio", "Por debajo del promedio"
)

class CuyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CuyRepository

    init {
        val database = CuyDatabase.getDatabase(application, viewModelScope)
        repository = CuyRepository(database.cuyDao())
    }

    val allCuyes: StateFlow<List<CuyEntity>> = repository.allCuyes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeCuyes: StateFlow<List<CuyEntity>> = repository.activeCuyes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeMales: StateFlow<List<CuyEntity>> = repository.activeMales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeFemales: StateFlow<List<CuyEntity>> = repository.activeFemales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWeightLogs: StateFlow<List<RegistroPesoEntity>> = repository.allWeightLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCruces: StateFlow<List<CruceEntity>> = repository.allCruces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeGestations: StateFlow<List<CruceEntity>> = repository.activeGestations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCamadas: StateFlow<List<CamadaEntity>> = repository.allCamadas
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingWeanings: StateFlow<List<CamadaEntity>> = repository.pendingWeanings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Notificaciones descartadas por el usuario en esta sesión
    private val _dismissedAlertIds = MutableStateFlow<Set<String>>(emptySet())
    val dismissedAlertIds = _dismissedAlertIds.asStateFlow()

    fun dismissAlert(alertKey: String) {
        _dismissedAlertIds.value = _dismissedAlertIds.value + alertKey
    }

    // Alertas de Destete Inteligentes (Camadas que alcanzan o superan los 21 días)
    val weaningAlerts: StateFlow<List<AlertaDestete>> = combine(
        pendingWeanings,
        allCuyes,
        dismissedAlertIds
    ) { camadas, cuyes, dismissed ->
        val cuyMap = cuyes.associateBy { it.id }
        val now = System.currentTimeMillis()
        val dayMillis = 86_400_000L

        camadas.mapNotNull { camada ->
            val key = "destete_${camada.id}"
            if (dismissed.contains(key)) return@mapNotNull null

            val diasEdad = ((now - camada.fechaParto) / dayMillis).toInt().coerceAtLeast(0)
            if (diasEdad >= 21) {
                val madre = cuyMap[camada.madreId]
                val madreNombre = madre?.nombre ?: "Madre #${camada.madreId}"
                AlertaDestete(
                    camada = camada,
                    madreNombre = madreNombre,
                    diasEdad = diasEdad,
                    mensaje = "Camada de $madreNombre lista para destete ($diasEdad días)."
                )
            } else {
                null
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Alertas de Parto Inteligentes (Gestación promedio 67 días, alerta inicia en día 62)
    val birthAlerts: StateFlow<List<AlertaParto>> = combine(
        activeGestations,
        allCuyes,
        dismissedAlertIds
    ) { gestaciones, cuyes, dismissed ->
        val cuyMap = cuyes.associateBy { it.id }
        val now = System.currentTimeMillis()
        val dayMillis = 86_400_000L

        gestaciones.mapNotNull { cruce ->
            val key = "parto_${cruce.id}"
            if (dismissed.contains(key)) return@mapNotNull null

            val diasGestacion = ((now - cruce.fechaMonta) / dayMillis).toInt().coerceAtLeast(0)
            if (diasGestacion >= 62) {
                val madre = cuyMap[cruce.hembraId]
                val madreNombre = madre?.nombre ?: "Madre #${cruce.hembraId}"
                val diasRestantes = 67 - diasGestacion

                val mensaje = if (diasRestantes > 0) {
                    "Parto próximo: $madreNombre en $diasRestantes días (Día $diasGestacion de gestación)."
                } else if (diasRestantes == 0) {
                    "Parto inminente: $madreNombre en fecha estimada (Día 67)."
                } else {
                    val retraso = -diasRestantes
                    "Parto próximo: $madreNombre con $retraso días de retraso (Día $diasGestacion)."
                }

                AlertaParto(
                    cruce = cruce,
                    madreNombre = madreNombre,
                    diasGestacion = diasGestacion,
                    diasRestantes = diasRestantes,
                    mensaje = mensaje,
                    esRetraso = diasRestantes < 0
                )
            } else {
                null
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cruces Aptos recomendados (Emparejamientos entre Machos y Hembras activos con F = 0%)
    val crucesAptos: StateFlow<List<AnalisisCruce>> = combine(
        activeMales,
        activeFemales,
        allCuyes
    ) { machos, hembras, todos ->
        val map = todos.associateBy { it.id }
        val lista = mutableListOf<AnalisisCruce>()

        for (m in machos) {
            for (h in hembras) {
                val analisis = GeneticCalculator.evaluarCruce(m, h, map)
                if (analisis.nivelRiesgo.esApto) {
                    lista.add(analisis)
                }
            }
        }
        lista.sortedBy { it.coeficienteF }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cruces Prohibidos (Peligro de consanguinidad entre animales activos)
    val crucesProhibidos: StateFlow<List<AnalisisCruce>> = combine(
        activeMales,
        activeFemales,
        allCuyes
    ) { machos, hembras, todos ->
        val map = todos.associateBy { it.id }
        val lista = mutableListOf<AnalisisCruce>()

        for (m in machos) {
            for (h in hembras) {
                val analisis = GeneticCalculator.evaluarCruce(m, h, map)
                if (!analisis.nivelRiesgo.esApto) {
                    lista.add(analisis)
                }
            }
        }
        lista.sortedByDescending { it.coeficienteF }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Operaciones CRUD y Negocio
    fun insertCuy(cuy: CuyEntity, initialWeightGrams: Float? = null, onComplete: ((Long) -> Unit)? = null) {
        viewModelScope.launch {
            val id = repository.insertCuy(cuy)
            if (initialWeightGrams != null && initialWeightGrams > 0) {
                repository.insertWeightLog(
                    RegistroPesoEntity(
                        cuyId = id,
                        fecha = cuy.fechaNacimiento,
                        pesoGramos = initialWeightGrams,
                        notas = "Peso inicial registrado"
                    )
                )
            }
            onComplete?.invoke(id)
        }
    }

    fun updateCuy(cuy: CuyEntity) {
        viewModelScope.launch {
            repository.updateCuy(cuy)
        }
    }

    /**
     * Soft Delete ("Dar de baja"):
     * Cambia el estado a Vendido, Consumido o Fallecido.
     * NUNCA rompe los vínculos genealógicos ni borra el cuy de la base de datos.
     */
    fun softDeleteCuy(id: Long, nuevoEstado: String, fechaBaja: Long, motivo: String?) {
        viewModelScope.launch {
            repository.softDeleteCuy(id, nuevoEstado, fechaBaja, motivo)
        }
    }

    fun reactivateCuy(id: Long) {
        viewModelScope.launch {
            repository.reactivateCuy(id)
        }
    }

    fun addWeightLog(cuyId: Long, fecha: Long, pesoGramos: Float, notas: String) {
        viewModelScope.launch {
            repository.insertWeightLog(
                RegistroPesoEntity(
                    cuyId = cuyId,
                    fecha = fecha,
                    pesoGramos = pesoGramos,
                    notas = notas
                )
            )
        }
    }

    fun deleteWeightLog(id: Long) {
        viewModelScope.launch {
            repository.deleteWeightLog(id)
        }
    }

    fun performBatchWeaning(
        camada: CamadaEntity,
        machos: Int,
        hembras: Int,
        pozaMachos: String,
        pozaHembras: String,
        fechaDestete: Long,
        pesoPromedioDesteteGramos: Float?,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            repository.performBatchWeaning(
                camada = camada,
                machosCount = machos,
                hembrasCount = hembras,
                pozaMachos = pozaMachos,
                pozaHembras = pozaHembras,
                fechaDestete = fechaDestete,
                pesoPromedioDesteteGramos = pesoPromedioDesteteGramos
            )
            onComplete()
        }
    }

    fun registerCruce(machoId: Long, hembraId: Long, fechaMonta: Long, poza: String, notas: String) {
        viewModelScope.launch {
            val fechaEstimadaParto = fechaMonta + (67 * 86_400_000L)
            repository.insertCruce(
                CruceEntity(
                    machoId = machoId,
                    hembraId = hembraId,
                    fechaMonta = fechaMonta,
                    fechaPartoEstimada = fechaEstimadaParto,
                    estado = "En gestación",
                    poza = poza,
                    notas = notas
                )
            )
        }
    }

    fun registerBirth(cruceId: Long?, madreId: Long, padreId: Long?, fechaParto: Long, criasVivas: Int, criasMuertas: Int, notas: String) {
        viewModelScope.launch {
            val fechaDestete = fechaParto + (21 * 86_400_000L)
            repository.insertCamada(
                CamadaEntity(
                    cruceId = cruceId,
                    madreId = madreId,
                    padreId = padreId,
                    fechaParto = fechaParto,
                    fechaDesteteProgramada = fechaDestete,
                    criasVivas = criasVivas,
                    criasMuertas = criasMuertas,
                    estadoDestete = "Pendiente",
                    notas = notas
                )
            )
            if (cruceId != null) {
                // Marcar cruce como Parida
                val cruces = allCruces.value
                val cruce = cruces.find { it.id == cruceId }
                if (cruce != null) {
                    repository.updateCruce(
                        cruce.copy(
                            estado = "Parida",
                            fechaPartoReal = fechaParto
                        )
                    )
                }
            }
        }
    }

    // Calcula métricas comparativas del cuy respecto a los promedios de la granja
    fun calcularMetricasCrecimiento(
        cuy: CuyEntity,
        pesosDelCuy: List<RegistroPesoEntity>,
        todosLosPesos: List<RegistroPesoEntity>,
        todosLosCuyes: List<CuyEntity>
    ): MetricasCrecimiento? {
        if (pesosDelCuy.isEmpty()) return null
        val ultimoPeso = pesosDelCuy.maxByOrNull { it.fecha }?.pesoGramos ?: return null

        val now = System.currentTimeMillis()
        val edadDias = ((now - cuy.fechaNacimiento) / 86_400_000L).toInt().coerceAtLeast(1)

        // Calcular ganancia diaria de peso (GDP = (ultimoPeso - primerPeso) / diasEntre)
        var gdp = 0f
        if (pesosDelCuy.size >= 2) {
            val primerPeso = pesosDelCuy.minByOrNull { it.fecha }!!
            val dias = ((ultimoPeso - primerPeso.pesoGramos) / (ultimoPeso.coerceAtLeast(1f)))
            val diasTranscurridos = ((pesosDelCuy.last().fecha - primerPeso.fecha) / 86_400_000L).toInt()
            if (diasTranscurridos > 0) {
                gdp = (pesosDelCuy.last().pesoGramos - primerPeso.pesoGramos) / diasTranscurridos
            }
        } else {
            // Ganancia aproximada desde nacimiento (~100g)
            gdp = (ultimoPeso - 100f).coerceAtLeast(0f) / edadDias
        }

        // Buscar pesos de otros cuyes en un rango de edad similar (+/- 20% de edad)
        val rangoMinDias = (edadDias * 0.75).toInt().coerceAtLeast(0)
        val rangoMaxDias = (edadDias * 1.25).toInt()

        val cuyMap = todosLosCuyes.associateBy { it.id }
        val pesosPoblacion = todosLosPesos.filter { p ->
            val animal = cuyMap[p.cuyId]
            if (animal != null) {
                val edadAlPesaje = ((p.fecha - animal.fechaNacimiento) / 86_400_000L).toInt()
                edadAlPesaje in rangoMinDias..rangoMaxDias
            } else false
        }.map { it.pesoGramos }

        val promedioGranja = if (pesosPoblacion.isNotEmpty()) {
            pesosPoblacion.average().toFloat()
        } else {
            // Estándar de raza de referencia si la base es pequeña
            when {
                edadDias <= 1 -> 110f
                edadDias <= 21 -> 110f + (edadDias * 10f)
                edadDias <= 60 -> 320f + ((edadDias - 21) * 11f)
                edadDias <= 90 -> 750f + ((edadDias - 60) * 8f)
                else -> 1100f
            }
        }

        val difPorcentual = if (promedioGranja > 0) {
            ((ultimoPeso - promedioGranja) / promedioGranja) * 100f
        } else 0f

        val estado = when {
            difPorcentual > 5f -> "Superior al promedio (+${"%.1f".format(difPorcentual)}%)"
            difPorcentual < -5f -> "Inferior al promedio (${"%.1f".format(difPorcentual)}%)"
            else -> "En el promedio de la granja (±5%)"
        }

        return MetricasCrecimiento(
            pesoActualGramos = ultimoPeso,
            promedioGranjaMismaEdad = promedioGranja,
            diferenciaPorcentual = difPorcentual,
            gananciaDiariaGramos = gdp,
            estadoComparativo = estado
        )
    }
}
