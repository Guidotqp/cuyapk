package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.SentimentVeryDissatisfied
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CuyEntity
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FarmGreen
import com.example.ui.theme.StatusConsumed
import com.example.ui.theme.StatusDeceased
import com.example.ui.theme.StatusSold

@Composable
fun DecommissionDialog(
    cuy: CuyEntity,
    onDismiss: () -> Unit,
    onConfirm: (nuevoEstado: String, motivo: String) -> Unit
) {
    val estadosBaja = listOf("Vendido", "Consumido", "Fallecido")
    var estadoSeleccionado by remember { mutableStateOf("Vendido") }
    var motivo by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = DangerRed
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Dar de Baja a ${cuy.nombre}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Código: ${cuy.codigo} • ${cuy.sexo}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Mensaje explicativo sobre la regla de preservación de pedigree
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color(0xFFB45309),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Preservación del Pedigree: El registro NO se eliminará. Este cuy se mantendrá intacto en el árbol genealógico de sus hijos, padres y hermanos, pero se retirará de las recomendaciones de cruce.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF78350F)
                        )
                    }
                }

                Text(
                    text = "Seleccione el motivo de la baja:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                estadosBaja.forEach { estado ->
                    val icono = when (estado) {
                        "Vendido" -> Icons.Default.Sell
                        "Consumido" -> Icons.Default.Restaurant
                        else -> Icons.Default.SentimentVeryDissatisfied
                    }
                    val tintColor = when (estado) {
                        "Vendido" -> StatusSold
                        "Consumido" -> StatusConsumed
                        else -> StatusDeceased
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { estadoSeleccionado = estado }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = estadoSeleccionado == estado,
                            onClick = { estadoSeleccionado = estado },
                            modifier = Modifier.testTag("radio_status_$estado")
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(icono, contentDescription = null, tint = tintColor, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = estado, style = MaterialTheme.typography.bodyMedium)
                    }
                }

                OutlinedTextField(
                    value = motivo,
                    onValueChange = { motivo = it },
                    label = { Text("Detalle o notas de la baja (opcional)") },
                    placeholder = { Text("Ej. Venta a Granja El Rosal, peso 1,200g") },
                    modifier = Modifier.fillMaxWidth().testTag("decommission_notes_input"),
                    minLines = 2,
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(estadoSeleccionado, motivo.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                modifier = Modifier.testTag("confirm_decommission_button")
            ) {
                Text("Confirmar Baja")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_decommission_button")
            ) {
                Text("Cancelar")
            }
        }
    )
}
