package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RegistroPesoEntity
import com.example.ui.theme.FarmGreen

@Composable
fun GrowthChart(
    registros: List<RegistroPesoEntity>,
    fechaNacimiento: Long,
    modifier: Modifier = Modifier
) {
    if (registros.isEmpty()) {
        Surface(
            modifier = modifier
                .fillMaxWidth()
                .height(180.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(12.dp)
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "No hay registros de peso suficientes para graficar.\nRegistra el peso al destete, recría y engorde.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    val registrosOrdenados = registros.sortedBy { it.fecha }
    val dayMillis = 86_400_000L

    val puntos = registrosOrdenados.map {
        val dias = ((it.fecha - fechaNacimiento) / dayMillis).toFloat().coerceAtLeast(0f)
        Pair(dias, it.pesoGramos)
    }

    val maxDias = (puntos.maxOfOrNull { it.first } ?: 90f).coerceAtLeast(60f)
    val minDias = 0f
    val maxPeso = ((puntos.maxOfOrNull { it.second } ?: 1200f) * 1.15f).coerceAtLeast(1300f)
    val minPeso = 0f

    val textMeasurer = rememberTextMeasurer()
    val axisColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
    val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)
    val textColor = MaterialTheme.colorScheme.onSurfaceVariant

    Column(modifier = modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(FarmGreen, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Peso del Cuy (g)", style = MaterialTheme.typography.labelSmall)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(12.dp, 6.dp)
                        .background(Color(0xFFC8E6C9).copy(alpha = 0.6f), RoundedCornerShape(2.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Rango Objetivo Saludable", style = MaterialTheme.typography.labelSmall)
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .padding(start = 36.dp, end = 16.dp, top = 12.dp, bottom = 24.dp)
        ) {
            val w = size.width
            val h = size.height

            fun getX(dias: Float): Float = ((dias - minDias) / (maxDias - minDias)) * w
            fun getY(peso: Float): Float = h - (((peso - minPeso) / (maxPeso - minPeso)) * h)

            // Líneas horizontales de referencia de peso
            val lineasGramos = listOf(250f, 500f, 750f, 1000f, 1250f)
            lineasGramos.forEach { pesoRef ->
                if (pesoRef <= maxPeso) {
                    val y = getY(pesoRef)
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                    )
                    drawText(
                        textMeasurer = textMeasurer,
                        text = "${pesoRef.toInt()}g",
                        topLeft = Offset(-32.dp.toPx(), y - 8.dp.toPx()),
                        style = TextStyle(fontSize = 9.sp, color = textColor)
                    )
                }
            }

            // Franja de Rango Objetivo Saludable (INIA)
            val bandaInferior = listOf(
                Pair(0f, 90f),
                Pair(21f, 260f),
                Pair(60f, 580f),
                Pair(90f, 820f),
                Pair(120f, 1000f),
                Pair(maxDias, 1050f)
            )
            val bandaSuperior = listOf(
                Pair(0f, 140f),
                Pair(21f, 390f),
                Pair(60f, 820f),
                Pair(90f, 1100f),
                Pair(120f, 1380f),
                Pair(maxDias, 1450f)
            )

            val pathBanda = Path()
            pathBanda.moveTo(getX(bandaInferior.first().first), getY(bandaInferior.first().second))
            bandaInferior.forEach { (d, p) ->
                if (d <= maxDias) pathBanda.lineTo(getX(d), getY(p))
            }
            bandaSuperior.reversed().forEach { (d, p) ->
                if (d <= maxDias) pathBanda.lineTo(getX(d), getY(p))
            }
            pathBanda.close()
            drawPath(path = pathBanda, color = Color(0xFFC8E6C9).copy(alpha = 0.35f))

            // Ejes X e Y
            drawLine(color = axisColor, start = Offset(0f, h), end = Offset(w, h), strokeWidth = 2.dp.toPx())
            drawLine(color = axisColor, start = Offset(0f, 0f), end = Offset(0f, h), strokeWidth = 2.dp.toPx())

            // Marcas en eje X
            val diasMarcas = listOf(0f, 21f, 45f, 60f, 90f, 120f).filter { it <= maxDias }
            diasMarcas.forEach { dia ->
                val x = getX(dia)
                drawLine(color = axisColor, start = Offset(x, h), end = Offset(x, h + 4.dp.toPx()), strokeWidth = 1.5.dp.toPx())
                val etiqueta = if (dia == 21f) "21d" else "${dia.toInt()}d"
                drawText(
                    textMeasurer = textMeasurer,
                    text = etiqueta,
                    topLeft = Offset(x - 10.dp.toPx(), h + 6.dp.toPx()),
                    style = TextStyle(fontSize = 9.sp, color = textColor)
                )
            }

            // Trazo de línea real
            if (puntos.size >= 2) {
                val lineaCuy = Path()
                puntos.forEachIndexed { i, pt ->
                    val x = getX(pt.first)
                    val y = getY(pt.second)
                    if (i == 0) lineaCuy.moveTo(x, y) else lineaCuy.lineTo(x, y)
                }
                drawPath(
                    path = lineaCuy,
                    color = FarmGreen,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Puntos con aro blanco
            puntos.forEach { pt ->
                val x = getX(pt.first)
                val y = getY(pt.second)
                drawCircle(color = Color.White, radius = 6.dp.toPx(), center = Offset(x, y))
                drawCircle(color = FarmGreen, radius = 4.5.dp.toPx(), center = Offset(x, y))
            }
        }
    }
}
