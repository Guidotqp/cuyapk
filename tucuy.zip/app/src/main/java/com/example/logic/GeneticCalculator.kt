package com.example.logic

import com.example.data.model.CuyEntity

enum class NivelRiesgo(val titulo: String, val descripcion: String, val esApto: Boolean) {
    OPTIMO("Óptimo (Sin parentesco)", "0% consanguinidad estimada. Máximo vigor híbrido y fertilidad.", true),
    LEVE("Aceptable (Baja consanguinidad)", "Menos del 6.25%. Aceptable si no hay alternativas directas.", true),
    RIESGOSO("Precaución (Primos hermanos)", "Consanguinidad 6.25%. Puede reducir ligeramente peso de camada.", false),
    PROHIBIDO_MEDIO_HERMANO("Prohibido (Medio hermanos)", "Consanguinidad 12.5%. Alto riesgo de depresión consanguínea.", false),
    PROHIBIDO_PARENTAL("Prohibido (Padre/Madre con Hijo/Hija)", "Consanguinidad 25.0%. Cruce directo endogámico muy perjudicial.", false),
    PROHIBIDO_HERMANOS("Prohibido (Hermanos de camada/completos)", "Consanguinidad 25.0%. Crítico: malformaciones y alta mortalidad.", false),
    PROHIBIDO_ABUELOS("Prohibido (Abuelo/Abuela con Nieto/Nieta)", "Consanguinidad 12.5%. Riesgo genético elevado.", false)
}

data class AnalisisCruce(
    val macho: CuyEntity,
    val hembra: CuyEntity,
    val nivelRiesgo: NivelRiesgo,
    val coeficienteF: Float, // Porcentaje de consanguinidad de la futura progenie
    val parentescoDetectado: String,
    val recomendaciones: String
)

object GeneticCalculator {

    /**
     * Evalúa la relación genética entre un macho y una hembra basada en el árbol genealógico.
     */
    fun evaluarCruce(
        macho: CuyEntity,
        hembra: CuyEntity,
        todosLosCuyes: Map<Long, CuyEntity>
    ): AnalisisCruce {
        // 1. Cruce idéntico (mismo animal)
        if (macho.id == hembra.id) {
            return AnalisisCruce(
                macho = macho,
                hembra = hembra,
                nivelRiesgo = NivelRiesgo.PROHIBIDO_PARENTAL,
                coeficienteF = 100f,
                parentescoDetectado = "Mismo individuo",
                recomendaciones = "No es posible cruzar un animal consigo mismo."
            )
        }

        // 2. Padre x Hija
        if (hembra.padreId == macho.id) {
            return AnalisisCruce(
                macho = macho,
                hembra = hembra,
                nivelRiesgo = NivelRiesgo.PROHIBIDO_PARENTAL,
                coeficienteF = 25.0f,
                parentescoDetectado = "El macho es padre directo de la hembra",
                recomendaciones = "PROHIBIDO: Provoca fijación de genes recesivos letales, crías débiles y nacimuertos."
            )
        }

        // 3. Madre x Hijo
        if (macho.madreId == hembra.id) {
            return AnalisisCruce(
                macho = macho,
                hembra = hembra,
                nivelRiesgo = NivelRiesgo.PROHIBIDO_PARENTAL,
                coeficienteF = 25.0f,
                parentescoDetectado = "La hembra es madre directa del macho",
                recomendaciones = "PROHIBIDO: Genera depresión endogámica severa y pérdida de fertilidad."
            )
        }

        // 4. Hermanos completos (Misma madre y mismo padre)
        val compartenMadre = macho.madreId != null && macho.madreId == hembra.madreId
        val compartenPadre = macho.padreId != null && macho.padreId == hembra.padreId

        if (compartenMadre && compartenPadre) {
            return AnalisisCruce(
                macho = macho,
                hembra = hembra,
                nivelRiesgo = NivelRiesgo.PROHIBIDO_HERMANOS,
                coeficienteF = 25.0f,
                parentescoDetectado = "Hermanos completos (Misma madre y mismo padre)",
                recomendaciones = "PROHIBIDO: Reduce drásticamente la viabilidad embrionaria y el peso al destete."
            )
        }

        // 5. Medios hermanos (Misma madre O mismo padre)
        if (compartenMadre || compartenPadre) {
            val padreComun = if (compartenMadre) "madre común" else "padre común"
            return AnalisisCruce(
                macho = macho,
                hembra = hembra,
                nivelRiesgo = NivelRiesgo.PROHIBIDO_MEDIO_HERMANO,
                coeficienteF = 12.5f,
                parentescoDetectado = "Medios hermanos ($padreComun)",
                recomendaciones = "PROHIBIDO: Aunque no comparten ambos progenitores, la consanguinidad es muy alta (12.5%)."
            )
        }

        // 6. Abuelo x Nieta o Abuela x Nieto
        val madreHembra = hembra.madreId?.let { todosLosCuyes[it] }
        val padreHembra = hembra.padreId?.let { todosLosCuyes[it] }
        val madreMacho = macho.madreId?.let { todosLosCuyes[it] }
        val padreMacho = macho.padreId?.let { todosLosCuyes[it] }

        val machoEsAbuelo = (madreHembra?.padreId == macho.id) || (padreHembra?.padreId == macho.id)
        val hembraEsAbuela = (madreMacho?.madreId == hembra.id) || (padreMacho?.madreId == hembra.id)

        if (machoEsAbuelo || hembraEsAbuela) {
            return AnalisisCruce(
                macho = macho,
                hembra = hembra,
                nivelRiesgo = NivelRiesgo.PROHIBIDO_ABUELOS,
                coeficienteF = 12.5f,
                parentescoDetectado = if (machoEsAbuelo) "El macho es abuelo de la hembra" else "La hembra es abuela del macho",
                recomendaciones = "PROHIBIDO: Cruce de segunda generación directa con 12.5% de consanguinidad."
            )
        }

        // 7. Primos hermanos (Al menos un progenitor de cada uno son hermanos)
        var sonPrimos = false
        val abuelosMacho = setOfNotNull(madreMacho?.madreId, madreMacho?.padreId, padreMacho?.madreId, padreMacho?.padreId)
        val abuelosHembra = setOfNotNull(madreHembra?.madreId, madreHembra?.padreId, padreHembra?.madreId, padreHembra?.padreId)
        val abuelosCompartidos = abuelosMacho.intersect(abuelosHembra)

        if (abuelosCompartidos.isNotEmpty()) {
            sonPrimos = true
        }

        if (sonPrimos) {
            return AnalisisCruce(
                macho = macho,
                hembra = hembra,
                nivelRiesgo = NivelRiesgo.RIESGOSO,
                coeficienteF = 6.25f,
                parentescoDetectado = "Primos hermanos (Comparten ancestros/abuelos)",
                recomendaciones = "PRECAUCIÓN: Consanguinidad moderada (6.25%). Se sugiere buscar otro reproductor ajeno."
            )
        }

        // 8. Cruce Óptimo
        return AnalisisCruce(
            macho = macho,
            hembra = hembra,
            nivelRiesgo = NivelRiesgo.OPTIMO,
            coeficienteF = 0.0f,
            parentescoDetectado = "Sin consanguinidad conocida (Líneas independientes)",
            recomendaciones = "EXCELENTE CRUCE: Óptima compatibilidad genética. Estimula vigor híbrido, crías saludables y camadas numerosas."
        )
    }

    /**
     * Encuentra hermanos conocidos de un animal para el selector de hermanos en el formulario.
     */
    fun obtenerHermanos(cuyId: Long?, todos: List<CuyEntity>): List<CuyEntity> {
        if (cuyId == null) return emptyList()
        val objetivo = todos.find { it.id == cuyId } ?: return emptyList()
        if (objetivo.madreId == null && objetivo.padreId == null) return emptyList()

        return todos.filter { otro ->
            otro.id != objetivo.id &&
            ((objetivo.madreId != null && otro.madreId == objetivo.madreId) ||
             (objetivo.padreId != null && otro.padreId == objetivo.padreId))
        }
    }
}
